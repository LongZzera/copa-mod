package br.cubecup.item;

import br.cubecup.match.Team;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Peca de uniforme (camisa, calcao ou meiao). Guarda o time a que pertence. */
public class UniformItem extends ArmorItem {

    private final Team team;

    public UniformItem(ArmorMaterial material, Type type, Team team, Settings settings) {
        super(material, type, settings);
        this.team = team;
    }

    public Team getTeam() {
        return team;
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext ctx) {
        tooltip.add(Text.translatable("tooltip.cubecup.team", team.displayName()).formatted(Formatting.GRAY));
    }
}
