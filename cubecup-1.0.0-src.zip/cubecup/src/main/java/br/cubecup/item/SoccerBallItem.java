package br.cubecup.item;

import br.cubecup.entity.SoccerBallEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Item que coloca a bola no mundo. Clique direito num bloco. */
public class SoccerBallItem extends Item {

    public SoccerBallItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (world.isClient) return ActionResult.SUCCESS;

        Vec3d spawn = Vec3d.ofCenter(context.getBlockPos().offset(context.getSide()));
        SoccerBallEntity ball = new SoccerBallEntity(world, spawn.x, spawn.y, spawn.z);
        world.spawnEntity(ball);

        world.playSound(null, ball.getX(), ball.getY(), ball.getZ(),
                SoundEvents.BLOCK_WOOL_PLACE, SoundCategory.PLAYERS, 0.8f, 1.4f);

        PlayerEntity player = context.getPlayer();
        if (player != null && !player.getAbilities().creativeMode) {
            context.getStack().decrement(1);
        }
        return ActionResult.CONSUME;
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, net.minecraft.client.item.TooltipContext ctx) {
        tooltip.add(Text.translatable("item.cubecup.soccer_ball.tooltip").formatted(Formatting.GRAY));
    }
}
