package br.cubecup.registry;

import br.cubecup.CubeCup;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

/** Aba criativa unica com tudo do mod, na ordem de registro. */
public final class ModItemGroups {

    public static ItemGroup MAIN;

    private ModItemGroups() {}

    public static void register() {
        MAIN = Registry.register(Registries.ITEM_GROUP, CubeCup.id("main"),
                FabricItemGroup.builder()
                        .icon(() -> new ItemStack(ModItems.SOCCER_BALL))
                        .displayName(Text.translatable("itemGroup.cubecup.main"))
                        .entries((context, entries) -> {
                            ModItems.CREATIVE_ORDER.forEach(entries::add);
                            ModBlocks.CREATIVE_ORDER.forEach(entries::add);
                        })
                        .build());
    }
}
