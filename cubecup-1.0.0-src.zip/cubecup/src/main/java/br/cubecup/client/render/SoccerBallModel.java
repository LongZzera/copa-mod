package br.cubecup.client.render;

import br.cubecup.entity.SoccerBallEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Modelo da bola: um cubo 12x12x12 (0.75 bloco), no espirito do Sulfur Cube.
 * Textura 64x32 com o layout padrao de cubo do Blockbench.
 */
public class SoccerBallModel extends EntityModel<SoccerBallEntity> {

    private final ModelPart cube;

    public SoccerBallModel(ModelPart root) {
        this.cube = root.getChild("cube");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();
        root.addChild("cube",
                ModelPartBuilder.create().uv(0, 0).cuboid(-6.0f, -6.0f, -6.0f, 12.0f, 12.0f, 12.0f),
                ModelTransform.NONE);
        return TexturedModelData.of(modelData, 64, 32);
    }

    @Override
    public void setAngles(SoccerBallEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        // A rotacao e aplicada no renderer (depende da direcao do movimento).
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        cube.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
