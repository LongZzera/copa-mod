package br.cubecup.match;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

/**
 * Guarda a partida ativa do servidor.
 *
 * Limitacao consciente: uma partida por servidor de cada vez. E o suficiente para
 * o formato "Copa do Mundo do Minecraft" e mantem a logica simples. Para varios
 * campos simultaneos, troque o campo estatico por um Map<RegistryKey<World>, Match>.
 */
public final class MatchManager {

    @Nullable private static Match current;

    private MatchManager() {}

    @Nullable
    public static Match get() {
        return current;
    }

    public static Match create(ServerWorld world, Vec3d center, int minutes, int scoreLimit) {
        if (current != null) current.dispose(world.getServer());
        current = new Match(world, center, minutes, scoreLimit);
        return current;
    }

    public static void destroy(MinecraftServer server) {
        if (current != null) {
            current.dispose(server);
            current = null;
        }
    }

    public static void registerEvents() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (current != null) current.tick(server);
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> current = null);

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity player = handler.player;
            if (current != null && player != null) current.leave(player);
        });
    }
}
