package br.cubecup.entity;

import br.cubecup.config.CubeCupConfig;
import br.cubecup.item.KickPower;
import br.cubecup.item.SoccerCleatsItem;
import br.cubecup.registry.ModEntities;
import br.cubecup.registry.ModItems;
import br.cubecup.registry.ModSounds;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.List;
import java.util.UUID;

/**
 * A bola de futebol.
 *
 * Fisica implementada a mao (nao usa ProjectileEntity) para ter controle total sobre:
 *  - gravidade e velocidade terminal
 *  - quique em 3 eixos separados (chao, parede X, parede Z)
 *  - atrito diferente no chao e no ar
 *  - drible: jogadores empurram a bola ao encostar
 *  - rotacao visual proporcional a velocidade
 *
 * O servidor e autoritativo; o cliente interpola entre os pacotes de posicao
 * (mesmo esquema do barco) para ficar suave mesmo com a bola voando forte.
 */
public class SoccerBallEntity extends Entity {

    /** Cor usada nas particulas de quique (padrao = amarelo enxofre do Sulfur Cube). */
    private static final TrackedData<Integer> TINT =
            DataTracker.registerData(SoccerBallEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private static final int DEFAULT_TINT = 0xD9D24A;

    // --- estado de jogo ---
    @Nullable private UUID lastKicker;
    private int lastKickerTicks;
    private int idleTicks;
    private int bounceCooldown;

    // --- interpolacao no cliente ---
    private double lerpX, lerpY, lerpZ;
    private int lerpSteps;

    // --- rotacao visual (usada pelo renderer) ---
    public float roll, prevRoll;
    public float spinYaw, prevSpinYaw;

    public SoccerBallEntity(EntityType<? extends SoccerBallEntity> type, World world) {
        super(type, world);
        this.intersectionChecked = true;
    }

    public SoccerBallEntity(World world, double x, double y, double z) {
        this(ModEntities.SOCCER_BALL, world);
        this.setPosition(x, y, z);
    }

    // ------------------------------------------------------------------
    // Boilerplate de entidade
    // ------------------------------------------------------------------

    @Override
    protected void initDataTracker() {
        this.dataTracker.startTracking(TINT, DEFAULT_TINT);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        if (nbt.containsUuid("LastKicker")) this.lastKicker = nbt.getUuid("LastKicker");
        if (nbt.contains("Tint")) this.dataTracker.set(TINT, nbt.getInt("Tint"));
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        if (lastKicker != null) nbt.putUuid("LastKicker", lastKicker);
        nbt.putInt("Tint", this.dataTracker.get(TINT));
    }

    @Override
    public Packet<ClientPlayPacketListener> createSpawnPacket() {
        return new EntitySpawnS2CPacket(this);
    }

    @Override public boolean canHit() { return true; }          // permite mirar/clicar nela
    @Override public boolean isCollidable() { return false; }    // jogadores atravessam (drible manual)
    @Override public boolean isPushable() { return false; }      // empurrao tratado manualmente
    @Override protected MoveEffect getMoveEffect() { return MoveEffect.NONE; }
    @Override public boolean isAttackable() { return true; }
    @Override public boolean shouldRender(double distance) { return distance < 16384.0; }

    public int tint() { return this.dataTracker.get(TINT); }
    public void setTint(int rgb) { this.dataTracker.set(TINT, rgb); }

    @Nullable public UUID getLastKicker() { return lastKickerTicks > 0 ? lastKicker : null; }

    // ------------------------------------------------------------------
    // Tick / fisica
    // ------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();

        prevRoll = roll;
        prevSpinYaw = spinYaw;
        if (lastKickerTicks > 0) lastKickerTicks--;
        if (bounceCooldown > 0) bounceCooldown--;

        if (this.getWorld().isClient) {
            clientTick();
        } else {
            physicsTick();
        }

        updateVisualSpin();
    }

    /** Cliente: interpola em direcao a ultima posicao recebida e continua a inercia entre pacotes. */
    private void clientTick() {
        if (lerpSteps > 0) {
            double x = getX() + (lerpX - getX()) / lerpSteps;
            double y = getY() + (lerpY - getY()) / lerpSteps;
            double z = getZ() + (lerpZ - getZ()) / lerpSteps;
            lerpSteps--;
            setPosition(x, y, z);
        } else {
            setPosition(getX() + getVelocity().x, getY() + getVelocity().y, getZ() + getVelocity().z);
        }
    }

    /** Servidor: simulacao completa. */
    private void physicsTick() {
        CubeCupConfig.Values cfg = CubeCupConfig.get();
        Vec3d velocity = this.getVelocity();

        // 1) Gravidade
        if (!this.hasNoGravity()) {
            velocity = velocity.add(0.0, -cfg.gravity, 0.0);
        }

        // 2) Agua: arrasto forte + empuxo (a bola boia)
        boolean inWater = this.isTouchingWater();
        if (inWater) {
            velocity = velocity.multiply(cfg.waterDrag, cfg.waterDrag, cfg.waterDrag).add(0.0, 0.028, 0.0);
        }

        // 3) Limite de velocidade (evita a bola virar um projetil interdimensional)
        if (velocity.lengthSquared() > cfg.maxSpeed * cfg.maxSpeed) {
            velocity = velocity.normalize().multiply(cfg.maxSpeed);
        }

        // 4) Move e descobre em quais eixos houve colisao comparando o deslocamento
        //    pretendido com o deslocamento efetivo.
        Vec3d intended = velocity;
        Vec3d before = this.getPos();
        this.move(MovementType.SELF, intended);
        Vec3d actual = this.getPos().subtract(before);

        double vx = velocity.x, vy = velocity.y, vz = velocity.z;
        boolean bouncedGround = false, bouncedWall = false;

        if (!MathHelper.approximatelyEquals(actual.x, intended.x)) {
            vx = -vx * cfg.wallBounciness;
            bouncedWall = true;
        }
        if (!MathHelper.approximatelyEquals(actual.z, intended.z)) {
            vz = -vz * cfg.wallBounciness;
            bouncedWall = true;
        }
        if (!MathHelper.approximatelyEquals(actual.y, intended.y)) {
            if (Math.abs(vy) > cfg.bounceThreshold) {
                vy = -vy * cfg.bounciness;
                bouncedGround = true;
            } else {
                vy = 0.0;
            }
        }

        // 5) Atrito
        boolean grounded = this.isOnGround();
        double friction = grounded ? slipperinessAdjustedFriction(cfg) : cfg.airFriction;
        vx *= friction;
        vz *= friction;
        if (Math.abs(vx) < 0.001) vx = 0.0;
        if (Math.abs(vz) < 0.001) vz = 0.0;

        this.setVelocity(vx, vy, vz);
        this.velocityModified = true;

        // 6) Efeitos de quique
        if ((bouncedGround || bouncedWall) && bounceCooldown == 0) {
            double impact = Math.max(Math.abs(vy), Math.hypot(vx, vz));
            if (impact > 0.14) {
                bounceCooldown = 3;
                playBounceEffects(impact);
            }
        }

        // 7) Drible: qualquer entidade encostando empurra a bola
        pushFromEntities(cfg);

        // 8) Housekeeping
        if (this.getVelocity().lengthSquared() < 1.0E-4) idleTicks++; else idleTicks = 0;
        if (cfg.idleDespawnTicks > 0 && idleTicks > cfg.idleDespawnTicks) this.discard();
        if (this.getY() < this.getWorld().getBottomY() - 16) this.discard();
    }

    /** Blocos escorregadios (gelo) deixam a bola mais rapida — otimo pro caos. */
    private double slipperinessAdjustedFriction(CubeCupConfig.Values cfg) {
        BlockPos below = BlockPos.ofFloored(getX(), getY() - 0.2, getZ());
        BlockState state = this.getWorld().getBlockState(below);
        float slipperiness = state.getBlock().getSlipperiness();
        // vanilla: 0.6 normal, 0.98 gelo azul
        double factor = MathHelper.clamp(slipperiness / 0.6, 0.8, 1.6);
        return MathHelper.clamp(cfg.groundFriction * factor, 0.0, 0.995);
    }

    /** Empurra a bola quando um jogador/mob encosta nela. */
    private void pushFromEntities(CubeCupConfig.Values cfg) {
        List<Entity> touching = this.getWorld().getOtherEntities(this,
                this.getBoundingBox().expand(0.12),
                e -> e.isAlive() && !(e instanceof SoccerBallEntity) && !(e instanceof SeatEntity));

        for (Entity entity : touching) {
            Vec3d away = new Vec3d(this.getX() - entity.getX(), 0.0, this.getZ() - entity.getZ());
            if (away.lengthSquared() < 1.0E-4) {
                away = new Vec3d(this.random.nextDouble() - 0.5, 0.0, this.random.nextDouble() - 0.5);
            }
            double entitySpeed = entity.getVelocity().horizontalLength();
            double strength = Math.max(0.10, entitySpeed * 1.9) * cfg.dribbleStrength;
            away = away.normalize().multiply(strength);
            this.addVelocity(away.x, 0.015, away.z);
            this.velocityModified = true;

            if (entity instanceof PlayerEntity player && !player.isSneaking()) {
                lastKicker = player.getUuid();
                lastKickerTicks = 200;
            }
        }
    }

    /** Rotacao visual: a bola rola na direcao do movimento, proporcional a velocidade. */
    private void updateVisualSpin() {
        Vec3d velocity = this.getVelocity();
        double horizontal = velocity.horizontalLength();
        if (horizontal > 0.005) {
            spinYaw = (float) (MathHelper.atan2(velocity.z, velocity.x) * MathHelper.DEGREES_PER_RADIAN);
        }
        // circunferencia aproximada de uma bola de 0.72 blocos
        roll += (float) (horizontal * 360.0 / (Math.PI * 0.72));
        if (roll > 3600f) { roll -= 3600f; prevRoll -= 3600f; }
    }

    private void playBounceEffects(double impact) {
        CubeCupConfig.Values cfg = CubeCupConfig.get();
        float volume = (float) MathHelper.clamp(impact * 0.8, 0.15, 1.0);

        if (cfg.bounceSound) {
            this.getWorld().playSound(null, this.getX(), this.getY(), this.getZ(),
                    ModSounds.bounce(), SoundCategory.NEUTRAL, volume,
                    1.1f + this.random.nextFloat() * 0.25f);
        }

        if (cfg.particles && this.getWorld() instanceof ServerWorld server) {
            int rgb = tint();
            DustParticleEffect dust = new DustParticleEffect(new Vector3f(
                    ((rgb >> 16) & 0xFF) / 255f,
                    ((rgb >> 8) & 0xFF) / 255f,
                    (rgb & 0xFF) / 255f), 1.1f);
            server.spawnParticles(dust, getX(), getY() + 0.1, getZ(),
                    (int) (3 + impact * 6), 0.18, 0.08, 0.18, 0.02);
        }
    }

    // ------------------------------------------------------------------
    // Chute
    // ------------------------------------------------------------------

    /** Chuta a bola na direcao em que o jogador olha. */
    public void kick(PlayerEntity player, KickPower power) {
        if (this.getWorld().isClient) return;
        CubeCupConfig.Values cfg = CubeCupConfig.get();

        double bonus = SoccerCleatsItem.kickMultiplier(player);
        double force = power.force() * bonus;

        Vec3d look = player.getRotationVec(1.0f);
        Vec3d direction = new Vec3d(look.x, look.y + power.lift(), look.z).normalize();

        // Desvio aleatorio: chuteiras reduzem o erro. E o que gera os gols malucos.
        double spread = Math.toRadians(cfg.kickSpread * SoccerCleatsItem.accuracyPenalty(player));
        if (spread > 0.0001) {
            direction = direction
                    .rotateY((float) ((this.random.nextDouble() - 0.5) * spread))
                    .add((this.random.nextDouble() - 0.5) * spread * 0.4, 0, 0)
                    .normalize();
        }

        this.setVelocity(direction.multiply(force));
        this.velocityModified = true;
        this.lastKicker = player.getUuid();
        this.lastKickerTicks = 200;
        this.idleTicks = 0;

        this.getWorld().playSound(null, getX(), getY(), getZ(), ModSounds.kick(),
                SoundCategory.PLAYERS, 1.0f, power.pitch() + this.random.nextFloat() * 0.1f);

        if (cfg.particles && this.getWorld() instanceof ServerWorld server) {
            server.spawnParticles(ParticleTypes.CRIT, getX(), getY() + 0.35, getZ(),
                    power == KickPower.POWER ? 22 : 8, 0.2, 0.2, 0.2, 0.35);
            if (power == KickPower.POWER) {
                server.spawnParticles(ParticleTypes.FLAME, getX(), getY() + 0.35, getZ(),
                        14, 0.15, 0.15, 0.15, 0.05);
            }
        }
    }

    /** Impulso generico (usado por flechas, explosoes e pelo comando /futebol bola impulso). */
    public void applyImpulse(Vec3d impulse, @Nullable PlayerEntity source) {
        this.addVelocity(impulse.x, impulse.y, impulse.z);
        this.velocityModified = true;
        if (source != null) {
            this.lastKicker = source.getUuid();
            this.lastKickerTicks = 200;
        }
    }

    // ------------------------------------------------------------------
    // Interacoes
    // ------------------------------------------------------------------

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (this.getWorld().isClient) return ActionResult.SUCCESS;

        // Shift + clique direito recolhe a bola como item.
        if (player.isSneaking()) {
            if (!player.getAbilities().creativeMode) {
                player.giveItemStack(new ItemStack(ModItems.SOCCER_BALL));
            }
            this.discard();
            return ActionResult.SUCCESS;
        }

        // Clique direito simples = toque leve (passe curto).
        kick(player, KickPower.WEAK);
        return ActionResult.SUCCESS;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (this.getWorld().isClient) return false;

        Entity attacker = source.getSource();
        if (attacker != null) {
            Vec3d push = attacker.getVelocity().normalize().multiply(Math.min(2.0, amount * 0.25 + 0.4));
            applyImpulse(new Vec3d(push.x, Math.max(0.15, push.y), push.z),
                    source.getAttacker() instanceof PlayerEntity p ? p : null);
        }
        return false; // a bola nunca "morre" por dano
    }

    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch,
                                               int interpolationSteps, boolean interpolate) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpSteps = interpolationSteps + 2;
        this.setYaw(yaw);
        this.setPitch(pitch);
    }

    /** Usado pelo detector de gol para creditar o autor. */
    @Nullable
    public LivingEntity resolveLastKicker() {
        if (lastKicker == null || !(this.getWorld() instanceof ServerWorld server)) return null;
        Entity entity = server.getEntity(lastKicker);
        return entity instanceof LivingEntity living ? living : null;
    }
}
