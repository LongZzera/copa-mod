package br.cubecup.block;

import br.cubecup.block.entity.GoalDetectorBlockEntity;
import br.cubecup.match.Team;
import br.cubecup.registry.ModBlockEntities;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Bloco invisivel-ish que fica atras da linha do gol e detecta a bola.
 *
 * Propriedade LARGE alterna entre gol pequeno (raio 2) e gol grande (raio 4).
 * Clique direito com a mao vazia para alternar.
 */
public class GoalDetectorBlock extends BlockWithEntity {

    public static final BooleanProperty LARGE = BooleanProperty.of("large");

    private final Team team;

    public GoalDetectorBlock(Team team, Settings settings) {
        super(settings);
        this.team = team;
        this.setDefaultState(this.getStateManager().getDefaultState().with(LARGE, false));
    }

    /** O time DONO do gol. Quem marca e o time adversario. */
    public Team getTeam() {
        return team;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LARGE);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player,
                              Hand hand, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        if (!player.getStackInHand(hand).isEmpty()) return ActionResult.PASS;

        boolean large = !state.get(LARGE);
        world.setBlockState(pos, state.with(LARGE, large), Block.NOTIFY_ALL);
        player.sendMessage(Text.translatable(large
                ? "message.cubecup.goal_large" : "message.cubecup.goal_small").formatted(Formatting.GRAY), true);
        return ActionResult.CONSUME;
    }

    /** BlockWithEntity esconde o bloco por padrao; aqui queremos o modelo normal. */
    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new GoalDetectorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        if (world.isClient) return null;
        return validateTicker(type, ModBlockEntities.GOAL_DETECTOR, GoalDetectorBlockEntity::serverTick);
    }
}
