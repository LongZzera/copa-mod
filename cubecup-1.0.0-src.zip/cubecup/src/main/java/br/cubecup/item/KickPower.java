package br.cubecup.item;

import br.cubecup.config.CubeCupConfig;

/** Os quatro niveis de chute. Os valores vem da config, entao sao ajustaveis em runtime. */
public enum KickPower {
    WEAK("fraco", 0.55f, 1.35f),
    MEDIUM("medio", 1.0f, 1.10f),
    STRONG("forte", 1.35f, 0.95f),
    POWER("powershot", 1.9f, 0.75f);

    private final String key;
    private final float liftMultiplier;
    private final float pitch;

    KickPower(String key, float liftMultiplier, float pitch) {
        this.key = key;
        this.liftMultiplier = liftMultiplier;
        this.pitch = pitch;
    }

    public String key() { return key; }
    public float pitch() { return pitch; }

    /** Forca base (blocos/tick) definida pela config. */
    public double force() {
        CubeCupConfig.Values c = CubeCupConfig.get();
        return switch (this) {
            case WEAK -> c.kickWeak;
            case MEDIUM -> c.kickMedium;
            case STRONG -> c.kickStrong;
            case POWER -> c.kickPowerShot;
        };
    }

    /** Elevacao aplicada por cima da direcao do olhar. */
    public double lift() {
        return CubeCupConfig.get().kickLift * liftMultiplier;
    }

    public static KickPower byOrdinal(int ordinal) {
        KickPower[] values = values();
        return values[Math.floorMod(ordinal, values.length)];
    }
}
