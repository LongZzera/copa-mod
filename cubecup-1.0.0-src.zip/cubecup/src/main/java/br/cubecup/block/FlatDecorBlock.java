package br.cubecup.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

/** Bloco chapado de 1 pixel de altura: linhas de campo, marca do penalti. */
public class FlatDecorBlock extends Block {

    private final VoxelShape shape;

    public FlatDecorBlock(Settings settings, double heightPixels) {
        super(settings);
        this.shape = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, heightPixels, 16.0);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return shape;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return shape;
    }
}
