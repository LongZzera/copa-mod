package br.cubecup.match;

import br.cubecup.config.CubeCupConfig;
import br.cubecup.entity.SoccerBallEntity;
import br.cubecup.registry.ModSounds;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Tudo que acontece quando a bola entra no gol: som, festa, placar e reinicio. */
public final class GoalHandler {

    private GoalHandler() {}

    public static void onGoal(ServerWorld world, BlockPos goalPos, Team scorer, SoccerBallEntity ball) {
        MinecraftServer server = world.getServer();
        LivingEntity author = ball.resolveLastKicker();

        Text authorName = author != null ? author.getDisplayName() : Text.translatable("message.cubecup.unknown_scorer");
        Text headline = Text.translatable("message.cubecup.goal_title").formatted(Formatting.GOLD, Formatting.BOLD);
        Text subtitle = Text.translatable("message.cubecup.goal_subtitle", scorer.displayName(), authorName);

        // Chuva de particulas no gol
        CubeCupConfig.Values cfg = CubeCupConfig.get();
        if (cfg.particles) {
            Vec3d center = Vec3d.ofCenter(goalPos).add(0, 1.5, 0);
            world.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, center.x, center.y, center.z, 120, 2.0, 1.5, 2.0, 0.35);
            world.spawnParticles(ParticleTypes.FIREWORK, center.x, center.y, center.z, 60, 2.0, 1.5, 2.0, 0.2);
        }

        world.playSound(null, goalPos, ModSounds.goal(), SoundCategory.PLAYERS, 1.4f, 1.0f);
        if (cfg.crowdOnGoal) {
            world.playSound(null, goalPos, ModSounds.crowd(), SoundCategory.AMBIENT, 1.2f, 1.0f);
        }

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            player.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.TitleS2CPacket(headline));
            player.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.SubtitleS2CPacket(subtitle));
        }
        server.getPlayerManager().broadcast(subtitle, false);

        Match match = MatchManager.get();
        if (match != null) {
            match.registerGoal(server, scorer, author);
        } else {
            // Sem partida ativa: apenas para a bola no lugar.
            ball.setVelocity(Vec3d.ZERO);
            ball.velocityModified = true;
        }
    }
}
