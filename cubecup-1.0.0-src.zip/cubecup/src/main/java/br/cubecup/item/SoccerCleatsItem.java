package br.cubecup.item;

import br.cubecup.config.CubeCupConfig;
import br.cubecup.match.Team;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Chuteiras: aumentam a forca do chute e reduzem o desvio aleatorio.
 * Os numeros vem da config (cleatsKickBonus / cleatsAccuracy).
 */
public class SoccerCleatsItem extends UniformItem {

    public SoccerCleatsItem(ArmorMaterial material, Team team, Settings settings) {
        super(material, Type.BOOTS, team, settings);
    }

    /** true se a entidade esta usando chuteiras nos pes. */
    public static boolean isWearing(LivingEntity entity) {
        return entity.getEquippedStack(EquipmentSlot.FEET).getItem() instanceof SoccerCleatsItem;
    }

    /** Multiplicador de forca do chute (1.0 sem chuteira). */
    public static double kickMultiplier(LivingEntity entity) {
        return isWearing(entity) ? CubeCupConfig.get().cleatsKickBonus : 1.0;
    }

    /**
     * Fator aplicado ao desvio aleatorio: 1.0 sem chuteira,
     * (1 - cleatsAccuracy) com chuteira. Menor = mais preciso.
     */
    public static double accuracyPenalty(LivingEntity entity) {
        return isWearing(entity) ? Math.max(0.0, 1.0 - CubeCupConfig.get().cleatsAccuracy) : 1.0;
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext ctx) {
        super.appendTooltip(stack, world, tooltip, ctx);
        CubeCupConfig.Values cfg = CubeCupConfig.get();
        tooltip.add(Text.translatable("tooltip.cubecup.cleats_power",
                String.format("%.0f%%", (cfg.cleatsKickBonus - 1.0) * 100.0)).formatted(Formatting.GOLD));
        tooltip.add(Text.translatable("tooltip.cubecup.cleats_accuracy",
                String.format("%.0f%%", cfg.cleatsAccuracy * 100.0)).formatted(Formatting.AQUA));
    }
}
