package br.cubecup.item;

import br.cubecup.match.Match;
import br.cubecup.match.MatchManager;
import br.cubecup.registry.ModSounds;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Apito do arbitro.
 *  - Clique direito: apita (som audivel num raio grande).
 *  - Shift + clique direito: pausa / retoma a partida ativa.
 */
public class WhistleItem extends Item {

    public WhistleItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                ModSounds.whistle(), SoundCategory.PLAYERS, 1.6f, 1.0f);
        player.getItemCooldownManager().set(this, 12);

        Match match = MatchManager.get();
        if (player.isSneaking() && match != null && player instanceof ServerPlayerEntity serverPlayer) {
            if (match.isRunning()) {
                match.pause(serverPlayer.getServer());
                player.sendMessage(Text.translatable("message.cubecup.match_paused").formatted(Formatting.YELLOW), true);
            } else {
                match.start(serverPlayer.getServer());
                player.sendMessage(Text.translatable("message.cubecup.match_resumed").formatted(Formatting.GREEN), true);
            }
        }
        return TypedActionResult.success(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, net.minecraft.client.item.TooltipContext ctx) {
        tooltip.add(Text.translatable("item.cubecup.whistle.tooltip").formatted(Formatting.GRAY));
    }
}
