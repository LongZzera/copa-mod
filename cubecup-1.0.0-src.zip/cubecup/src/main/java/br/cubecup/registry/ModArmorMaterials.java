package br.cubecup.registry;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

/**
 * Materiais de armadura dos uniformes.
 *
 * IMPORTANTE (1.20.1): o vanilla monta o caminho da textura como
 * "textures/models/armor/<getName()>_layer_N.png" e o resolve no namespace minecraft.
 * Por isso as texturas ficam em assets/minecraft/textures/models/armor/ com nomes
 * unicos (soccer_red_layer_1.png etc). Nao ha conflito com o vanilla.
 */
public enum ModArmorMaterials implements ArmorMaterial {

    SOCCER_RED("soccer_red", 5, new int[]{1, 2, 2, 1}, 18, 0.0f, 0.0f),
    SOCCER_BLUE("soccer_blue", 5, new int[]{1, 2, 2, 1}, 18, 0.0f, 0.0f),
    CLEATS_RED("cleats_red", 9, new int[]{2, 3, 3, 2}, 22, 0.0f, 0.0f),
    CLEATS_BLUE("cleats_blue", 9, new int[]{2, 3, 3, 2}, 22, 0.0f, 0.0f);

    private static final int[] BASE_DURABILITY = new int[]{13, 15, 16, 11};

    private final String name;
    private final int durabilityMultiplier;
    private final int[] protection;
    private final int enchantability;
    private final float toughness;
    private final float knockbackResistance;

    ModArmorMaterials(String name, int durabilityMultiplier, int[] protection,
                      int enchantability, float toughness, float knockbackResistance) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.protection = protection;
        this.enchantability = enchantability;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
    }

    @Override
    public int getDurability(ArmorItem.Type type) {
        return BASE_DURABILITY[type.getEquipmentSlot().getEntitySlotId()] * durabilityMultiplier;
    }

    @Override
    public int getProtection(ArmorItem.Type type) {
        return protection[type.getEquipmentSlot().getEntitySlotId()];
    }

    @Override public int getEnchantability() { return enchantability; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ITEM_ARMOR_EQUIP_LEATHER; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.LEATHER, Items.STRING); }
    @Override public String getName() { return name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockbackResistance; }
}
