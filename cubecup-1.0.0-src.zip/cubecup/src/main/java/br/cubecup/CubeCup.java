package br.cubecup;

import br.cubecup.command.CubeCupCommands;
import br.cubecup.config.CubeCupConfig;
import br.cubecup.entity.SoccerBallEntity;
import br.cubecup.item.KickPower;
import br.cubecup.match.MatchManager;
import br.cubecup.network.ModPackets;
import br.cubecup.registry.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ponto de entrada comum (cliente + servidor) do mod Cube Cup.
 *
 * Ordem de inicializacao importa: config -> sons -> blocos -> itens -> block entities
 * -> entidades -> creative tab -> rede -> comandos -> eventos.
 */
public class CubeCup implements ModInitializer {

    public static final String MOD_ID = "cubecup";
    public static final Logger LOGGER = LoggerFactory.getLogger("CubeCup");

    /** Atalho para criar Identifiers no namespace do mod. */
    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        CubeCupConfig.load();

        ModSounds.register();
        ModBlocks.register();
        ModItems.register();
        ModBlockEntities.register();
        ModEntities.register();
        ModItemGroups.register();

        ModPackets.registerServerReceivers();
        CubeCupCommands.register();
        MatchManager.registerEvents();

        // Clique esquerdo na bola = chute medio (sem consumir durabilidade / sem dano).
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (entity instanceof SoccerBallEntity ball) {
                if (!world.isClient) {
                    ball.kick(player, KickPower.MEDIUM);
                }
                return ActionResult.SUCCESS; // cancela o dano padrao
            }
            return ActionResult.PASS;
        });

        LOGGER.info("[Cube Cup] Mod carregado. Bola de enxofre pronta para o caos.");
    }
}
