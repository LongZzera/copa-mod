package br.cubecup.block.entity;

import br.cubecup.block.GoalDetectorBlock;
import br.cubecup.entity.SoccerBallEntity;
import br.cubecup.match.GoalHandler;
import br.cubecup.match.Team;
import br.cubecup.registry.ModBlockEntities;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.List;

/**
 * Varre a area do gol todo tick procurando a bola.
 *
 * Usar uma caixa de deteccao (em vez de "cruzar a linha" geometricamente) evita
 * o classico bug de tunelamento: mesmo com a bola a 4 blocos/tick, se ela terminar
 * o tick dentro da area o gol conta.
 */
public class GoalDetectorBlockEntity extends BlockEntity {

    private static final int COOLDOWN_TICKS = 60;

    private int cooldown;

    public GoalDetectorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GOAL_DETECTOR, pos, state);
    }

    public static void serverTick(World world, BlockPos pos, BlockState state, GoalDetectorBlockEntity be) {
        if (!(world instanceof ServerWorld serverWorld)) return;
        if (be.cooldown > 0) {
            be.cooldown--;
            return;
        }
        if (!(state.getBlock() instanceof GoalDetectorBlock goalBlock)) return;

        boolean large = state.get(GoalDetectorBlock.LARGE);
        double radius = large ? 4.0 : 2.0;
        double height = large ? 3.5 : 2.0;

        Box area = new Box(pos).expand(radius, 0.0, radius).stretch(0.0, height, 0.0);
        List<SoccerBallEntity> balls = serverWorld.getEntitiesByClass(SoccerBallEntity.class, area, b -> true);
        if (balls.isEmpty()) return;

        SoccerBallEntity ball = balls.get(0);
        Team owner = goalBlock.getTeam();      // gol de quem levou
        Team scorer = owner.opposite();        // quem marcou

        be.cooldown = COOLDOWN_TICKS;
        GoalHandler.onGoal(serverWorld, pos, scorer, ball);
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.putInt("Cooldown", cooldown);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        cooldown = nbt.getInt("Cooldown");
    }
}
