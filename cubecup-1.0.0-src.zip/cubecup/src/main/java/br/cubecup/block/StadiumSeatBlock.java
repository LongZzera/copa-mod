package br.cubecup.block;

import br.cubecup.entity.SeatEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.util.List;

/** Assento de arquibancada: clique direito para sentar. */
public class StadiumSeatBlock extends Block {

    private static final VoxelShape SHAPE = Block.createCuboidShape(1.0, 0.0, 1.0, 15.0, 9.0, 15.0);

    public StadiumSeatBlock(Settings settings) {
        super(settings);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player,
                              Hand hand, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        if (player.hasVehicle() || !player.getStackInHand(hand).isEmpty()) return ActionResult.PASS;

        // Ja existe alguem sentado aqui?
        List<SeatEntity> existing = world.getEntitiesByClass(SeatEntity.class,
                new Box(pos).expand(0.2), s -> true);
        if (!existing.isEmpty()) return ActionResult.FAIL;

        SeatEntity seat = new SeatEntity(world, pos, 0.42);
        world.spawnEntity(seat);
        player.startRiding(seat);
        return ActionResult.CONSUME;
    }
}
