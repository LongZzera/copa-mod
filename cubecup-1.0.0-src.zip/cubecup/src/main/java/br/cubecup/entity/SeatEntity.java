package br.cubecup.entity;

import br.cubecup.registry.ModEntities;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Entidade invisivel que serve de "cadeira" nos assentos de arquibancada.
 * Some sozinha assim que o jogador desmonta ou o bloco e quebrado.
 */
public class SeatEntity extends Entity {

    private BlockPos seatPos = BlockPos.ORIGIN;

    public SeatEntity(EntityType<? extends SeatEntity> type, World world) {
        super(type, world);
        this.noClip = true;
        this.setNoGravity(true);
        this.setSilent(true);
    }

    public SeatEntity(World world, BlockPos pos, double yOffset) {
        this(ModEntities.SEAT, world);
        this.seatPos = pos;
        this.setPosition(pos.getX() + 0.5, pos.getY() + yOffset, pos.getZ() + 0.5);
    }

    @Override protected void initDataTracker() {}
    @Override protected void readCustomDataFromNbt(NbtCompound nbt) {}
    @Override protected void writeCustomDataToNbt(NbtCompound nbt) {}

    @Override
    public Packet<ClientPlayPacketListener> createSpawnPacket() {
        return new EntitySpawnS2CPacket(this);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) return;
        // Sem passageiro ou bloco removido -> some.
        if (!this.hasPassengers() || this.getWorld().getBlockState(seatPos).isAir()) {
            this.discard();
        }
    }

    @Override
    public double getMountedHeightOffset() {
        return 0.05;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengerList().isEmpty();
    }
}
