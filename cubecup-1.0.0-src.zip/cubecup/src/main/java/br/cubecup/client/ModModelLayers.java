package br.cubecup.client;

import br.cubecup.CubeCup;
import net.minecraft.client.render.entity.model.EntityModelLayer;

/** Camadas de modelo registradas pelo cliente. */
public final class ModModelLayers {

    public static final EntityModelLayer SOCCER_BALL =
            new EntityModelLayer(CubeCup.id("soccer_ball"), "main");

    private ModModelLayers() {}
}
