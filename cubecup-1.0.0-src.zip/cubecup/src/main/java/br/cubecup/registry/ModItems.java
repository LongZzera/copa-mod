package br.cubecup.registry;

import br.cubecup.CubeCup;
import br.cubecup.item.*;
import br.cubecup.match.Team;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.List;

/** Todos os itens do mod: bola, uniformes, arbitragem e trofeus. */
public final class ModItems {

    public static final List<Item> CREATIVE_ORDER = new ArrayList<>();

    // Bola
    public static Item SOCCER_BALL;
    public static Item BALL_BAG;

    // Arbitragem
    public static Item WHISTLE;
    public static Item YELLOW_CARD;
    public static Item RED_CARD;

    // Uniformes (RED)
    public static Item RED_JERSEY;
    public static Item RED_SHORTS;
    public static Item RED_SOCKS;
    public static Item RED_CLEATS;

    // Uniformes (BLUE)
    public static Item BLUE_JERSEY;
    public static Item BLUE_SHORTS;
    public static Item BLUE_SOCKS;
    public static Item BLUE_CLEATS;

    // Trofeus
    public static Item TROPHY_WORLD_CUP;
    public static Item TROPHY_CHAMPIONS;
    public static Item TROPHY_LIBERTADORES;
    public static Item BALLON_DOR;

    private ModItems() {}

    private static <T extends Item> T register(String name, T item) {
        Registry.register(Registries.ITEM, CubeCup.id(name), item);
        CREATIVE_ORDER.add(item);
        return item;
    }

    public static void register() {
        SOCCER_BALL = register("soccer_ball", new SoccerBallItem(new Item.Settings().maxCount(16)));
        BALL_BAG = register("ball_bag", new BallBagItem(new Item.Settings().maxCount(1)));

        WHISTLE = register("whistle", new WhistleItem(new Item.Settings().maxCount(1)));
        YELLOW_CARD = register("yellow_card", new RefereeCardItem(false, new Item.Settings().maxCount(1)));
        RED_CARD = register("red_card", new RefereeCardItem(true, new Item.Settings().maxCount(1)));

        // --- Uniformes ---
        RED_JERSEY = register("red_jersey", new UniformItem(ModArmorMaterials.SOCCER_RED, ArmorItem.Type.CHESTPLATE, Team.RED, new Item.Settings()));
        RED_SHORTS = register("red_shorts", new UniformItem(ModArmorMaterials.SOCCER_RED, ArmorItem.Type.LEGGINGS, Team.RED, new Item.Settings()));
        RED_SOCKS  = register("red_socks",  new UniformItem(ModArmorMaterials.SOCCER_RED, ArmorItem.Type.BOOTS, Team.RED, new Item.Settings()));
        RED_CLEATS = register("red_cleats", new SoccerCleatsItem(ModArmorMaterials.CLEATS_RED, Team.RED, new Item.Settings()));

        BLUE_JERSEY = register("blue_jersey", new UniformItem(ModArmorMaterials.SOCCER_BLUE, ArmorItem.Type.CHESTPLATE, Team.BLUE, new Item.Settings()));
        BLUE_SHORTS = register("blue_shorts", new UniformItem(ModArmorMaterials.SOCCER_BLUE, ArmorItem.Type.LEGGINGS, Team.BLUE, new Item.Settings()));
        BLUE_SOCKS  = register("blue_socks",  new UniformItem(ModArmorMaterials.SOCCER_BLUE, ArmorItem.Type.BOOTS, Team.BLUE, new Item.Settings()));
        BLUE_CLEATS = register("blue_cleats", new SoccerCleatsItem(ModArmorMaterials.CLEATS_BLUE, Team.BLUE, new Item.Settings()));

        // --- Trofeus (puramente decorativos, brilham) ---
        TROPHY_WORLD_CUP = register("trophy_world_cup", new TrophyItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
        TROPHY_CHAMPIONS = register("trophy_champions", new TrophyItem(new Item.Settings().maxCount(1).rarity(Rarity.RARE)));
        TROPHY_LIBERTADORES = register("trophy_libertadores", new TrophyItem(new Item.Settings().maxCount(1).rarity(Rarity.RARE)));
        BALLON_DOR = register("ballon_dor", new TrophyItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
    }

    /** Kit completo de um time, usado pelo /futebol time entrar. */
    public static ItemStack[] uniformFor(Team team) {
        return team == Team.RED
                ? new ItemStack[]{ new ItemStack(RED_CLEATS), new ItemStack(RED_SHORTS), new ItemStack(RED_JERSEY) }
                : new ItemStack[]{ new ItemStack(BLUE_CLEATS), new ItemStack(BLUE_SHORTS), new ItemStack(BLUE_JERSEY) };
    }
}
