package br.cubecup.item;

import br.cubecup.entity.SoccerBallEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Saco de bolas: guarda ate {@link #CAPACITY} bolas.
 *  - Clique direito num bloco: tira uma bola do saco.
 *  - Shift + clique direito no ar: recolhe todas as bolas num raio de 12 blocos.
 */
public class BallBagItem extends Item {

    public static final int CAPACITY = 8;
    private static final String KEY = "Balls";

    public BallBagItem(Settings settings) {
        super(settings);
    }

    public static int count(ItemStack stack) {
        NbtCompound nbt = stack.getNbt();
        return nbt == null ? 0 : MathHelper.clamp(nbt.getInt(KEY), 0, CAPACITY);
    }

    private static void setCount(ItemStack stack, int value) {
        stack.getOrCreateNbt().putInt(KEY, MathHelper.clamp(value, 0, CAPACITY));
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        ItemStack stack = context.getStack();
        PlayerEntity player = context.getPlayer();
        if (world.isClient) return ActionResult.SUCCESS;

        boolean creative = player != null && player.getAbilities().creativeMode;
        if (count(stack) <= 0 && !creative) {
            if (player != null) player.sendMessage(Text.translatable("message.cubecup.bag_empty").formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }

        Vec3d spawn = Vec3d.ofCenter(context.getBlockPos().offset(context.getSide()));
        world.spawnEntity(new SoccerBallEntity(world, spawn.x, spawn.y, spawn.z));
        if (!creative) setCount(stack, count(stack) - 1);

        world.playSound(null, spawn.x, spawn.y, spawn.z, SoundEvents.BLOCK_WOOL_PLACE,
                SoundCategory.PLAYERS, 0.8f, 1.3f);
        return ActionResult.CONSUME;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!player.isSneaking()) return TypedActionResult.pass(stack);
        if (world.isClient) return TypedActionResult.success(stack);

        Box area = player.getBoundingBox().expand(12.0);
        List<SoccerBallEntity> balls = world.getEntitiesByClass(SoccerBallEntity.class, area, b -> true);

        int stored = 0;
        for (SoccerBallEntity ball : balls) {
            if (count(stack) >= CAPACITY) break;
            setCount(stack, count(stack) + 1);
            ball.discard();
            stored++;
        }

        player.sendMessage(Text.translatable("message.cubecup.bag_collected", stored, count(stack)), true);
        world.playSound(null, player.getBlockPos(), SoundEvents.ITEM_BUNDLE_INSERT,
                SoundCategory.PLAYERS, 0.9f, 1.0f);
        return TypedActionResult.success(stack);
    }

    @Override public boolean isItemBarVisible(ItemStack stack) { return count(stack) > 0; }
    @Override public int getItemBarStep(ItemStack stack) { return Math.round(count(stack) * 13.0f / CAPACITY); }
    @Override public int getItemBarColor(ItemStack stack) { return 0xD9D24A; }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, net.minecraft.client.item.TooltipContext ctx) {
        tooltip.add(Text.translatable("item.cubecup.ball_bag.tooltip", count(stack), CAPACITY).formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("item.cubecup.ball_bag.tooltip2").formatted(Formatting.DARK_GRAY));
    }
}
