# ⚽ Cube Cup — Mod de Futebol para Minecraft 1.20.1 (Fabric)

Partidas de futebol caóticas no estilo **Copa do Mundo do Minecraft / Cube Cup**: bola com física
própria (inspirada visualmente no *Sulfur Cube* do Chaos Cubed), chutes de quatro intensidades,
detecção automática de gol, placar, uniformes, árbitro com apito e cartões, arquibancada e troféus.

> **Status:** o código está completo e organizado, mas **não foi compilado neste ambiente**
> (sem acesso à rede para baixar Gradle/Yarn/Fabric API). Rode `./gradlew build` uma vez e
> corrija eventuais ajustes de mapeamento — a estrutura e as APIs seguem o padrão 1.20.1.

---

## 📦 Instalação

**Para jogar:**
1. Instale o [Fabric Loader](https://fabricmc.net/use/) para 1.20.1.
2. Baixe a [Fabric API](https://modrinth.com/mod/fabric-api) para 1.20.1.
3. Coloque `cubecup-1.0.0.jar` + `fabric-api` na pasta `mods/`.
4. Em servidor, o mod precisa estar **no servidor e nos clientes** (as teclas de chute são client-side).

**Para compilar:**
```bash
cd cubecup
gradle wrapper             # 1x: gera gradlew + gradle-wrapper.jar (não versionado aqui)
./gradlew build            # jar em build/libs/
./gradlew runClient        # testar direto
```
> Requer JDK 17. O `gradle/wrapper/gradle-wrapper.properties` já está fixado no Gradle 8.1.1.

**Para regenerar os assets** (texturas, sons, JSONs) depois de mexer nas paletas:
```bash
pip install pillow numpy   # ffmpeg precisa estar no PATH
python3 tools/gen_assets.py
python3 tools/gen_textures.py
python3 tools/gen_sounds.py
```

---

## 🎮 Como jogar

### Partida rápida (5 minutos)
```
/futebol partida criar ~ ~ ~ 10 5     # centro no seu pé, 10 minutos, até 5 gols
/futebol partida spawn vermelho       # vá até o lado vermelho e rode
/futebol partida spawn azul           # vá até o lado azul e rode
/futebol partida iniciar
```
Cada jogador entra com `/futebol time auto` (ou `entrar vermelho` / `entrar azul`).
O uniforme é vestido automaticamente.

### Montando o gol
1. Construa a estrutura com **Trave** e **Rede** (só decoração).
2. Coloque **1 Detector de Gol** do time *dono* daquele gol atrás da linha, no meio.
   - `goal_detector_red` = gol do time vermelho → quem marcar ali é o **azul**.
3. Clique direito com a mão vazia no detector para alternar **área pequena (raio 2)** ↔
   **área grande (raio 4)**.

### Teclas (Opções ▸ Controles ▸ Cube Cup)

| Ação | Padrão |
|---|---|
| Chute fraco | `G` |
| Chute médio | `H` |
| Chute forte | `J` |
| Powershot | `R` |
| Chute médio | clique **esquerdo** na bola |
| Toque leve / passe | clique **direito** na bola |
| Guardar a bola | **Shift** + clique direito na bola |

Andar contra a bola a empurra (drible). Correr empurra mais forte.

---

## 🧰 Conteúdo

**Itens**
- Bola de Futebol, Saco de Bolas (guarda 8, recolhe com Shift + clique direito)
- Apito do Árbitro (Shift + clique = pausa/retoma a partida)
- Cartão Amarelo (2 amarelos viram vermelho) e Cartão Vermelho (expulsa do time)
- Uniformes: camisa, calção, meião e **chuteira** para vermelho e azul
  - a chuteira dá `+35%` de força e reduz `70%` do desvio aleatório (configurável)
- Troféus decorativos: Taça do Mundo, Orelhuda, Libertadores, Bola de Ouro

**Blocos**
- Detector de Gol (vermelho/azul), Trave, Rede
- Linha de Campo, Marca do Pênalti, Bandeirinha de escanteio
- Assentos de arquibancada (dá para **sentar** com clique direito), Placa de Publicidade

---

## ⌨️ Comandos

Raiz: `/futebol` (alias `/cubecup`).

| Comando | Nível | O que faz |
|---|---|---|
| `/futebol partida criar [centro] [minutos] [placarMáximo]` | 2 | cria a partida |
| `/futebol partida iniciar` / `pausar` / `parar` / `resetar` | 2 | ciclo de vida |
| `/futebol partida spawn <vermelho\|azul>` | 2 | define o spawn do time na sua posição |
| `/futebol partida bola <x y z>` | 2 | define o centro do campo |
| `/futebol partida info` | 2 | placar, tempo, estado |
| `/futebol time entrar <vermelho\|azul>` | 0 | entra num time |
| `/futebol time auto` | 0 | entra no time com menos gente |
| `/futebol time sair` | 0 | sai do time |
| `/futebol bola spawn` / `centro` / `limpar` | 2 | gerenciar bolas |
| `/futebol placar resetar` | 2 | zera o placar |
| `/futebol config recarregar` | 2 | recarrega `config/cubecup.json` sem reiniciar |

---

## ⚙️ Configuração

Arquivo: `.minecraft/config/cubecup.json` (criado no primeiro boot).

```jsonc
{
  // --- física ---
  "gravity": 0.045,          // maior = bola mais pesada
  "bounciness": 0.68,        // 0.9+ deixa a bola muito maluca (recomendo pro caos)
  "groundFriction": 0.90,
  "airFriction": 0.995,
  "wallBounciness": 0.72,
  "maxSpeed": 4.0,
  "bounceThreshold": 0.09,
  "dribbleStrength": 1.0,

  // --- chutes ---
  "kickWeak": 0.55, "kickMedium": 1.05, "kickStrong": 1.75, "kickPowerShot": 2.90,
  "kickLift": 0.22,          // 0 = rasteiro, 0.5 = balão
  "kickReach": 4.0,
  "kickCooldownTicks": 5,
  "cleatsKickBonus": 1.35,
  "cleatsAccuracy": 0.70,
  "kickSpread": 3.5,         // desvio aleatório em graus — o "caos" do Cube Cup

  // --- partida ---
  "defaultMatchMinutes": 10,
  "defaultScoreLimit": 5,
  "kickoffDelayTicks": 60,
  "autoEquipUniform": true,
  "teleportOnKickoff": true,

  // --- efeitos ---
  "particles": true,
  "customSounds": true,      // false = usa sons vanilla equivalentes
  "crowdOnGoal": true
}
```

### Presets divertidos

| Estilo | Ajustes |
|---|---|
| **Realista** | `bounciness 0.45`, `kickSpread 1.0`, `cleatsAccuracy 0.9` |
| **Cube Cup clássico** | padrão |
| **Caos total** | `bounciness 0.95`, `gravity 0.02`, `kickPowerShot 6.0`, `kickSpread 12` |
| **Futebol lunar** | `gravity 0.012`, `airFriction 0.999` |

---

## 🏗️ Estrutura do projeto

```
src/main/java/br/cubecup/
├─ CubeCup.java                  entrypoint comum
├─ config/CubeCupConfig.java     JSON via Gson, recarregável em runtime
├─ registry/                     ModItems, ModBlocks, ModEntities, ModSounds,
│                                ModBlockEntities, ModItemGroups, ModArmorMaterials
├─ entity/
│  ├─ SoccerBallEntity.java      ★ física, quique, drible, chute
│  └─ SeatEntity.java            assento invisível da arquibancada
├─ item/
│  ├─ KickPower.java             enum das 4 forças (lê da config)
│  ├─ SoccerBallItem / BallBagItem
│  ├─ WhistleItem / RefereeCardItem
│  └─ UniformItem / SoccerCleatsItem / TrophyItem
├─ block/
│  ├─ GoalDetectorBlock (+ block/entity/GoalDetectorBlockEntity)
│  ├─ GoalNetBlock / FlatDecorBlock / CornerFlagBlock / StadiumSeatBlock
├─ match/
│  ├─ Team.java                  enum vermelho/azul
│  ├─ Match.java                 estado, placar, boss bar, kickoff
│  ├─ MatchManager.java          partida ativa do servidor + eventos
│  └─ GoalHandler.java           festa do gol
├─ command/CubeCupCommands.java  árvore Brigadier
├─ network/ModPackets.java       pacote KICK (raycast feito no servidor)
└─ client/
   ├─ CubeCupClient.java, ModKeybinds.java, ModModelLayers.java
   └─ render/SoccerBallModel, SoccerBallRenderer, SeatEntityRenderer
```

### Decisões de arquitetura que valem explicar

**Física manual em vez de `ProjectileEntity`.** A bola compara o deslocamento *pretendido*
com o *efetivo* após `move()` para descobrir em quais eixos houve colisão. Isso permite quicar
em X, Y e Z com coeficientes diferentes (parede ≠ chão) — o que `ProjectileEntity` não dá.

**Detector de gol por caixa, não por linha.** Testar "a bola cruzou o plano do gol" falha quando
ela viaja 4 blocos por tick (tunelamento). O detector varre uma `Box` todo tick: se a bola
terminar o tick dentro da área, o gol conta.

**Raycast do chute no servidor.** O cliente só manda *qual tecla* foi apertada. Quem decide qual
bola foi acertada é o servidor, então cliente modificado não chuta bola do outro lado do mapa.

**Uma partida por servidor.** Simplifica muito a lógica e cobre o formato Cube Cup. Para vários
campos simultâneos, troque o campo estático em `MatchManager` por um
`Map<RegistryKey<World>, Match>` — o resto do código já recebe o `Match` por parâmetro.

**Sons com fallback.** Os `.ogg` são sintetizados por `tools/gen_sounds.py`. Se você desligar
`customSounds` na config, o mod usa sons vanilla equivalentes e continua funcionando.

---

## 🎨 Texturas e resource pack

Todas as texturas são **geradas por código** em `tools/gen_textures.py` (paleta no topo do
arquivo). Mude as cores e rode de novo, ou substitua os PNGs à mão:

```
assets/cubecup/textures/item/*.png          16×16
assets/cubecup/textures/block/*.png         16×16
assets/cubecup/textures/entity/soccer_ball.png   64×32 (cubo 12³)
assets/minecraft/textures/models/armor/*.png     64×32 (uniformes)
```

> ⚠️ As texturas de armadura ficam em `assets/minecraft/` de propósito: no 1.20.1 o vanilla
> resolve `textures/models/armor/<nome>_layer_N.png` **no namespace minecraft**. Os nomes são
> únicos (`soccer_red_layer_1.png` etc.), então não há conflito.

Como o mod usa modelos JSON e texturas normais, **qualquer resource pack pode sobrescrever tudo**
sem precisar recompilar. Para modelos animados mais elaborados (bola deformando no chute),
descomente as linhas do GeckoLib em `build.gradle` e troque `SoccerBallRenderer` por um
`GeoEntityRenderer`.

---

## 🐛 Coisas que provavelmente vão precisar de ajuste

- **Yarn muda de build.** Se `./gradlew build` reclamar de método inexistente, cheque o
  mapeamento em [linkie.shedaniel.dev](https://linkie.shedaniel.dev/) — os pontos mais sensíveis
  são `Entity#updateTrackedPositionAndAngles`, `ArmorMaterial#getDurability(ArmorItem.Type)` e a
  API de `Scoreboard` (que muda de novo no 1.20.3+).
- **Jitter da bola no multiplayer.** Se ficar tremendo, aumente o buffer de interpolação em
  `SoccerBallEntity#updateTrackedPositionAndAngles` (`interpolationSteps + 2` → `+ 3`).
- **Lag de física com muitas bolas.** Cada bola faz um `getOtherEntities` por tick. Acima de
  ~30 bolas simultâneas vale limitar via `idleDespawnTicks` na config.

---

## 📄 Licença

MIT — veja `LICENSE`. Os sons e texturas gerados são originais e podem ser usados livremente.
