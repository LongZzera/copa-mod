package br.cubecup.match;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Os dois times da partida. */
public enum Team {
    RED("vermelho", Formatting.RED, 0xE03030),
    BLUE("azul", Formatting.BLUE, 0x3050E0);

    private final String id;
    private final Formatting color;
    private final int rgb;

    Team(String id, Formatting color, int rgb) {
        this.id = id;
        this.color = color;
        this.rgb = rgb;
    }

    public String id() { return id; }
    public Formatting color() { return color; }
    public int rgb() { return rgb; }

    public Team opposite() {
        return this == RED ? BLUE : RED;
    }

    public Text displayName() {
        return Text.translatable("team.cubecup." + id).formatted(color);
    }

    public static Team byId(String value) {
        for (Team team : values()) {
            if (team.id.equalsIgnoreCase(value) || team.name().equalsIgnoreCase(value)) return team;
        }
        return RED;
    }
}
