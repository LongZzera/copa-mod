package br.cubecup.registry;

import br.cubecup.CubeCup;
import br.cubecup.block.entity.GoalDetectorBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/** Block entities (apenas o detector de gol precisa de tick). */
public final class ModBlockEntities {

    public static BlockEntityType<GoalDetectorBlockEntity> GOAL_DETECTOR;

    private ModBlockEntities() {}

    public static void register() {
        GOAL_DETECTOR = Registry.register(Registries.BLOCK_ENTITY_TYPE, CubeCup.id("goal_detector"),
                FabricBlockEntityTypeBuilder.create(GoalDetectorBlockEntity::new,
                        ModBlocks.GOAL_DETECTOR_RED, ModBlocks.GOAL_DETECTOR_BLUE).build());
    }
}
