package br.cubecup.item;

import br.cubecup.match.Match;
import br.cubecup.match.MatchManager;
import br.cubecup.registry.ModSounds;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Cartoes do arbitro. Clique direito em um jogador para adverti-lo/expulsa-lo.
 *  - Amarelo: aviso publico + lentidao. O segundo amarelo vira vermelho.
 *  - Vermelho: expulsao (sai do time e vira espectador da partida).
 */
public class RefereeCardItem extends Item {

    private final boolean red;

    public RefereeCardItem(boolean red, Settings settings) {
        super(settings);
        this.red = red;
    }

    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity user, LivingEntity entity, Hand hand) {
        if (user.getWorld().isClient) return ActionResult.SUCCESS;
        if (!(entity instanceof ServerPlayerEntity target)) return ActionResult.PASS;

        Match match = MatchManager.get();
        boolean expel = red;

        if (!red && match != null) {
            int cards = match.addYellowCard(target.getUuid());
            if (cards >= 2) expel = true;
        }

        user.getWorld().playSound(null, user.getX(), user.getY(), user.getZ(),
                ModSounds.whistle(), SoundCategory.PLAYERS, 1.4f, red ? 0.8f : 1.2f);
        user.getItemCooldownManager().set(this, 20);

        if (expel) {
            broadcast(target, Text.translatable("message.cubecup.red_card", target.getDisplayName())
                    .formatted(Formatting.RED, Formatting.BOLD));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 2));
            if (match != null) match.expel(target);
        } else {
            broadcast(target, Text.translatable("message.cubecup.yellow_card", target.getDisplayName())
                    .formatted(Formatting.YELLOW));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
        }
        return ActionResult.SUCCESS;
    }

    private void broadcast(ServerPlayerEntity target, Text message) {
        if (target.getServer() != null) {
            target.getServer().getPlayerManager().broadcast(message, false);
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, net.minecraft.client.item.TooltipContext ctx) {
        tooltip.add(Text.translatable(red ? "item.cubecup.red_card.tooltip" : "item.cubecup.yellow_card.tooltip")
                .formatted(Formatting.GRAY));
    }
}
