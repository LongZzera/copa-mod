package br.cubecup.match;

import br.cubecup.config.CubeCupConfig;
import br.cubecup.entity.SoccerBallEntity;
import br.cubecup.registry.ModItems;
import br.cubecup.registry.ModSounds;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.scoreboard.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Uma partida de futebol.
 *
 * Estados: SETUP -> RUNNING <-> PAUSED -> FINISHED
 * O placar aparece no sidebar e o tempo restante numa boss bar.
 */
public class Match {

    public enum State { SETUP, RUNNING, PAUSED, FINISHED }

    private static final String OBJECTIVE = "cubecup";

    private final RegistryKey<World> worldKey;
    private final Map<Team, Vec3d> spawns = new EnumMap<>(Team.class);
    private final Map<Team, Integer> score = new EnumMap<>(Team.class);
    private final Map<UUID, Team> members = new HashMap<>();
    private final Map<UUID, Integer> yellowCards = new HashMap<>();

    private Vec3d ballSpawn;
    private State state = State.SETUP;
    private int durationTicks;
    private int remainingTicks;
    private int scoreLimit;
    private int kickoffCountdown;

    private final ServerBossBar bossBar = new ServerBossBar(
            Text.translatable("bossbar.cubecup.match"), BossBar.Color.GREEN, BossBar.Style.NOTCHED_10);

    public Match(ServerWorld world, Vec3d center, int minutes, int scoreLimit) {
        this.worldKey = world.getRegistryKey();
        this.ballSpawn = center;
        this.durationTicks = Math.max(1, minutes) * 60 * 20;
        this.remainingTicks = this.durationTicks;
        this.scoreLimit = scoreLimit;
        this.score.put(Team.RED, 0);
        this.score.put(Team.BLUE, 0);
        // Spawns padrao: 12 blocos de cada lado do centro no eixo X.
        this.spawns.put(Team.RED, center.add(-12, 0, 0));
        this.spawns.put(Team.BLUE, center.add(12, 0, 0));
    }

    // ------------------------------------------------------------------
    // Configuracao
    // ------------------------------------------------------------------

    public void setBallSpawn(Vec3d pos) { this.ballSpawn = pos; }
    public Vec3d getBallSpawn() { return ballSpawn; }
    public void setSpawn(Team team, Vec3d pos) { spawns.put(team, pos); }
    public Vec3d getSpawn(Team team) { return spawns.getOrDefault(team, ballSpawn); }
    public void setScoreLimit(int limit) { this.scoreLimit = limit; }
    public int getScoreLimit() { return scoreLimit; }
    public RegistryKey<World> worldKey() { return worldKey; }
    public State getState() { return state; }
    public boolean isRunning() { return state == State.RUNNING; }
    public int getScore(Team team) { return score.getOrDefault(team, 0); }
    public int getRemainingSeconds() { return remainingTicks / 20; }

    public void setDurationMinutes(int minutes) {
        this.durationTicks = Math.max(1, minutes) * 60 * 20;
        this.remainingTicks = this.durationTicks;
    }

    // ------------------------------------------------------------------
    // Times
    // ------------------------------------------------------------------

    @Nullable
    public Team teamOf(UUID uuid) {
        return members.get(uuid);
    }

    public void join(ServerPlayerEntity player, Team team) {
        members.put(player.getUuid(), team);
        bossBar.addPlayer(player);

        if (CubeCupConfig.get().autoEquipUniform) {
            ItemStack[] kit = ModItems.uniformFor(team);
            player.equipStack(EquipmentSlot.FEET, kit[0]);
            player.equipStack(EquipmentSlot.LEGS, kit[1]);
            player.equipStack(EquipmentSlot.CHEST, kit[2]);
        }

        player.sendMessage(Text.translatable("message.cubecup.joined", team.displayName()), false);
        broadcast(player.getServer(), Text.translatable("message.cubecup.player_joined",
                player.getDisplayName(), team.displayName()).formatted(Formatting.GRAY));
        updateScoreboard(player.getServer());
    }

    /** Entra no time com menos jogadores. */
    public Team autoJoin(ServerPlayerEntity player) {
        long red = members.values().stream().filter(t -> t == Team.RED).count();
        long blue = members.values().stream().filter(t -> t == Team.BLUE).count();
        Team team = red <= blue ? Team.RED : Team.BLUE;
        join(player, team);
        return team;
    }

    public void leave(ServerPlayerEntity player) {
        members.remove(player.getUuid());
        bossBar.removePlayer(player);
        updateScoreboard(player.getServer());
    }

    public void expel(ServerPlayerEntity player) {
        leave(player);
        yellowCards.remove(player.getUuid());
    }

    public int addYellowCard(UUID uuid) {
        int count = yellowCards.merge(uuid, 1, Integer::sum);
        return count;
    }

    public Collection<UUID> memberIds() {
        return Collections.unmodifiableSet(members.keySet());
    }

    // ------------------------------------------------------------------
    // Ciclo de vida
    // ------------------------------------------------------------------

    public void start(MinecraftServer server) {
        this.state = State.RUNNING;
        this.kickoffCountdown = CubeCupConfig.get().kickoffDelayTicks;
        forEachMember(server, p -> bossBar.addPlayer(p));
        kickoff(server, true);
        updateScoreboard(server);
        broadcast(server, Text.translatable("message.cubecup.match_started").formatted(Formatting.GREEN, Formatting.BOLD));
    }

    public void pause(MinecraftServer server) {
        if (state == State.RUNNING) state = State.PAUSED;
        updateScoreboard(server);
    }

    public void stop(MinecraftServer server) {
        this.state = State.FINISHED;
        bossBar.clearPlayers();
        bossBar.setVisible(false);
        announceResult(server);
    }

    public void reset(MinecraftServer server) {
        score.put(Team.RED, 0);
        score.put(Team.BLUE, 0);
        yellowCards.clear();
        remainingTicks = durationTicks;
        state = State.SETUP;
        kickoff(server, true);
        updateScoreboard(server);
        broadcast(server, Text.translatable("message.cubecup.match_reset").formatted(Formatting.AQUA));
    }

    public void dispose(MinecraftServer server) {
        bossBar.clearPlayers();
        bossBar.setVisible(false);
        ServerScoreboard scoreboard = server.getScoreboard();
        ScoreboardObjective objective = scoreboard.getNullableObjective(OBJECTIVE);
        if (objective != null) scoreboard.removeObjective(objective);
    }

    // ------------------------------------------------------------------
    // Tick
    // ------------------------------------------------------------------

    public void tick(MinecraftServer server) {
        if (state != State.RUNNING) return;

        if (kickoffCountdown > 0) {
            kickoffCountdown--;
            if (kickoffCountdown == 0) {
                broadcast(server, Text.translatable("message.cubecup.kickoff").formatted(Formatting.GOLD));
                ServerWorld world = server.getWorld(worldKey);
                if (world != null) {
                    world.playSound(null, blockPosOfBall(), ModSounds.whistle(), SoundCategory.PLAYERS, 1.5f, 1.0f);
                }
            }
            return;
        }

        remainingTicks--;
        bossBar.setPercent(Math.max(0f, (float) remainingTicks / (float) durationTicks));
        bossBar.setName(Text.translatable("bossbar.cubecup.time",
                formatTime(remainingTicks / 20),
                getScore(Team.RED), getScore(Team.BLUE)));

        if (remainingTicks % 20 == 0) updateScoreboard(server);

        if (remainingTicks <= 0) {
            stop(server);
        }
    }

    // ------------------------------------------------------------------
    // Gols
    // ------------------------------------------------------------------

    public void registerGoal(MinecraftServer server, Team scorer, @Nullable LivingEntity author) {
        if (state == State.FINISHED) return;
        score.merge(scorer, 1, Integer::sum);
        updateScoreboard(server);

        if (scoreLimit > 0 && getScore(scorer) >= scoreLimit) {
            stop(server);
            return;
        }

        kickoffCountdown = CubeCupConfig.get().kickoffDelayTicks;
        kickoff(server, CubeCupConfig.get().teleportOnKickoff);
    }

    /** Recoloca a bola no centro (e opcionalmente os jogadores nos spawns). */
    public void kickoff(MinecraftServer server, boolean teleportPlayers) {
        ServerWorld world = server.getWorld(worldKey);
        if (world == null) return;

        // Remove bolas antigas perto do campo e coloca uma nova no centro.
        world.getEntitiesByClass(SoccerBallEntity.class,
                new Box(ballSpawn.add(-60, -30, -60), ballSpawn.add(60, 30, 60)), b -> true)
                .forEach(SoccerBallEntity::discard);

        SoccerBallEntity ball = new SoccerBallEntity(world, ballSpawn.x, ballSpawn.y + 1.0, ballSpawn.z);
        world.spawnEntity(ball);

        if (teleportPlayers) {
            forEachMember(server, player -> {
                Team team = members.get(player.getUuid());
                if (team == null) return;
                Vec3d spawn = getSpawn(team);
                player.teleport(world, spawn.x, spawn.y, spawn.z, player.getYaw(), player.getPitch());
            });
        }
    }

    // ------------------------------------------------------------------
    // Placar / mensagens
    // ------------------------------------------------------------------

    public void updateScoreboard(@Nullable MinecraftServer server) {
        if (server == null) return;
        ServerScoreboard scoreboard = server.getScoreboard();
        ScoreboardObjective objective = scoreboard.getNullableObjective(OBJECTIVE);
        if (objective == null) {
            objective = scoreboard.addObjective(OBJECTIVE, ScoreboardCriterion.DUMMY,
                    Text.translatable("scoreboard.cubecup.title").formatted(Formatting.GOLD, Formatting.BOLD),
                    ScoreboardCriterion.RenderType.INTEGER);
        }
        scoreboard.setObjectiveSlot(Scoreboard.SIDEBAR_DISPLAY_SLOT_ID, objective);

        scoreboard.getPlayerScore(Formatting.RED + "Vermelho", objective).setScore(getScore(Team.RED));
        scoreboard.getPlayerScore(Formatting.BLUE + "Azul", objective).setScore(getScore(Team.BLUE));
        scoreboard.getPlayerScore(Formatting.GRAY + "Tempo (s)", objective).setScore(getRemainingSeconds());
    }

    private void announceResult(MinecraftServer server) {
        int red = getScore(Team.RED);
        int blue = getScore(Team.BLUE);
        Text result;
        if (red == blue) {
            result = Text.translatable("message.cubecup.draw", red, blue).formatted(Formatting.YELLOW);
        } else {
            Team winner = red > blue ? Team.RED : Team.BLUE;
            result = Text.translatable("message.cubecup.winner", winner.displayName(), red, blue)
                    .formatted(Formatting.GOLD, Formatting.BOLD);
        }
        broadcast(server, result);
        forEachMember(server, player -> player.sendMessage(result, false));

        ServerWorld world = server.getWorld(worldKey);
        if (world != null) {
            world.playSound(null, blockPosOfBall(), ModSounds.whistle(), SoundCategory.PLAYERS, 2.0f, 0.85f);
            world.playSound(null, blockPosOfBall(), ModSounds.crowd(), SoundCategory.AMBIENT, 1.4f, 1.0f);
        }
    }

    private net.minecraft.util.math.BlockPos blockPosOfBall() {
        return net.minecraft.util.math.BlockPos.ofFloored(ballSpawn.x, ballSpawn.y, ballSpawn.z);
    }

    private void broadcast(@Nullable MinecraftServer server, Text text) {
        if (server != null) server.getPlayerManager().broadcast(text, false);
    }

    private void forEachMember(MinecraftServer server, java.util.function.Consumer<ServerPlayerEntity> action) {
        for (UUID uuid : new ArrayList<>(members.keySet())) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
            if (player != null) action.accept(player);
        }
    }

    public static String formatTime(int totalSeconds) {
        int minutes = Math.max(0, totalSeconds) / 60;
        int seconds = Math.max(0, totalSeconds) % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
}
