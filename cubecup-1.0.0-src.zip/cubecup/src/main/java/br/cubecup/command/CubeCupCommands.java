package br.cubecup.command;

import br.cubecup.config.CubeCupConfig;
import br.cubecup.entity.SoccerBallEntity;
import br.cubecup.match.Match;
import br.cubecup.match.MatchManager;
import br.cubecup.match.Team;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.Vec3ArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Comandos do mod. Raiz: /futebol (alias /cubecup).
 *
 * Admin (nivel 2): partida, bola, placar, config
 * Jogadores (nivel 0): time entrar/sair/auto
 */
public final class CubeCupCommands {

    private CubeCupCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            build(dispatcher, "futebol");
            dispatcher.register(literal("cubecup").redirect(dispatcher.getRoot().getChild("futebol")));
        });
    }

    private static void build(CommandDispatcher<ServerCommandSource> dispatcher, String root) {
        dispatcher.register(literal(root)

            // ---------------- PARTIDA ----------------
            .then(literal("partida")
                .requires(src -> src.hasPermissionLevel(2))
                .then(literal("criar")
                    .executes(ctx -> createMatch(ctx, ctx.getSource().getPosition(),
                            CubeCupConfig.get().defaultMatchMinutes, CubeCupConfig.get().defaultScoreLimit))
                    .then(argument("centro", Vec3ArgumentType.vec3())
                        .executes(ctx -> createMatch(ctx, Vec3ArgumentType.getVec3(ctx, "centro"),
                                CubeCupConfig.get().defaultMatchMinutes, CubeCupConfig.get().defaultScoreLimit))
                        .then(argument("minutos", IntegerArgumentType.integer(1, 240))
                            .executes(ctx -> createMatch(ctx, Vec3ArgumentType.getVec3(ctx, "centro"),
                                    IntegerArgumentType.getInteger(ctx, "minutos"),
                                    CubeCupConfig.get().defaultScoreLimit))
                            .then(argument("placarMaximo", IntegerArgumentType.integer(0, 99))
                                .executes(ctx -> createMatch(ctx, Vec3ArgumentType.getVec3(ctx, "centro"),
                                        IntegerArgumentType.getInteger(ctx, "minutos"),
                                        IntegerArgumentType.getInteger(ctx, "placarMaximo")))))))
                .then(literal("iniciar").executes(CubeCupCommands::startMatch))
                .then(literal("pausar").executes(CubeCupCommands::pauseMatch))
                .then(literal("parar").executes(CubeCupCommands::stopMatch))
                .then(literal("resetar").executes(CubeCupCommands::resetMatch))
                .then(literal("info").executes(CubeCupCommands::matchInfo))
                .then(literal("spawn")
                    .then(argument("time", StringArgumentType.word())
                        .executes(ctx -> setSpawn(ctx, Team.byId(StringArgumentType.getString(ctx, "time"))))))
                .then(literal("bola")
                    .then(argument("pos", Vec3ArgumentType.vec3())
                        .executes(ctx -> setBallSpawn(ctx, Vec3ArgumentType.getVec3(ctx, "pos"))))))

            // ---------------- TIME (jogadores) ----------------
            .then(literal("time")
                .then(literal("entrar")
                    .then(argument("time", StringArgumentType.word())
                        .executes(ctx -> joinTeam(ctx, Team.byId(StringArgumentType.getString(ctx, "time"))))))
                .then(literal("auto").executes(CubeCupCommands::autoJoin))
                .then(literal("sair").executes(CubeCupCommands::leaveTeam)))

            // ---------------- BOLA ----------------
            .then(literal("bola")
                .requires(src -> src.hasPermissionLevel(2))
                .then(literal("spawn").executes(CubeCupCommands::spawnBall))
                .then(literal("centro").executes(CubeCupCommands::recenterBall))
                .then(literal("limpar").executes(CubeCupCommands::clearBalls)))

            // ---------------- PLACAR ----------------
            .then(literal("placar")
                .requires(src -> src.hasPermissionLevel(2))
                .then(literal("resetar").executes(CubeCupCommands::resetScore))
                .then(literal("mostrar").executes(CubeCupCommands::matchInfo)))

            // ---------------- CONFIG ----------------
            .then(literal("config")
                .requires(src -> src.hasPermissionLevel(2))
                .then(literal("recarregar").executes(ctx -> {
                    CubeCupConfig.load();
                    feedback(ctx, Text.translatable("message.cubecup.config_reloaded").formatted(Formatting.GREEN));
                    return 1;
                })))
        );
    }

    // ------------------------------------------------------------------
    // Implementacoes
    // ------------------------------------------------------------------

    private static int createMatch(CommandContext<ServerCommandSource> ctx, Vec3d center, int minutes, int scoreLimit) {
        ServerWorld world = ctx.getSource().getWorld();
        Match match = MatchManager.create(world, center, minutes, scoreLimit);
        match.updateScoreboard(ctx.getSource().getServer());
        feedback(ctx, Text.translatable("message.cubecup.match_created",
                minutes, scoreLimit == 0 ? "-" : String.valueOf(scoreLimit)).formatted(Formatting.GREEN));
        feedback(ctx, Text.translatable("message.cubecup.match_created_hint").formatted(Formatting.GRAY));
        return 1;
    }

    private static int startMatch(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        match.start(ctx.getSource().getServer());
        return 1;
    }

    private static int pauseMatch(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        match.pause(ctx.getSource().getServer());
        feedback(ctx, Text.translatable("message.cubecup.match_paused").formatted(Formatting.YELLOW));
        return 1;
    }

    private static int stopMatch(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        match.stop(ctx.getSource().getServer());
        return 1;
    }

    private static int resetMatch(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        match.reset(ctx.getSource().getServer());
        return 1;
    }

    private static int resetScore(CommandContext<ServerCommandSource> ctx) {
        return resetMatch(ctx);
    }

    private static int matchInfo(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        feedback(ctx, Text.literal("=== Cube Cup ===").formatted(Formatting.GOLD));
        feedback(ctx, Text.translatable("message.cubecup.info_score",
                match.getScore(Team.RED), match.getScore(Team.BLUE)));
        feedback(ctx, Text.translatable("message.cubecup.info_time", Match.formatTime(match.getRemainingSeconds())));
        feedback(ctx, Text.translatable("message.cubecup.info_state", match.getState().name()));
        feedback(ctx, Text.translatable("message.cubecup.info_players", match.memberIds().size()));
        return 1;
    }

    private static int setSpawn(CommandContext<ServerCommandSource> ctx, Team team) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        match.setSpawn(team, ctx.getSource().getPosition());
        feedback(ctx, Text.translatable("message.cubecup.spawn_set", team.displayName()).formatted(Formatting.GREEN));
        return 1;
    }

    private static int setBallSpawn(CommandContext<ServerCommandSource> ctx, Vec3d pos) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        match.setBallSpawn(pos);
        feedback(ctx, Text.translatable("message.cubecup.ball_spawn_set").formatted(Formatting.GREEN));
        return 1;
    }

    private static int joinTeam(CommandContext<ServerCommandSource> ctx, Team team) {
        Match match = requireMatch(ctx);
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (match == null || player == null) return 0;
        match.join(player, team);
        return 1;
    }

    private static int autoJoin(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (match == null || player == null) return 0;
        match.autoJoin(player);
        return 1;
    }

    private static int leaveTeam(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (match == null || player == null) return 0;
        match.leave(player);
        feedback(ctx, Text.translatable("message.cubecup.left").formatted(Formatting.GRAY));
        return 1;
    }

    private static int spawnBall(CommandContext<ServerCommandSource> ctx) {
        ServerWorld world = ctx.getSource().getWorld();
        Vec3d pos = ctx.getSource().getPosition();
        world.spawnEntity(new SoccerBallEntity(world, pos.x, pos.y + 1.0, pos.z));
        feedback(ctx, Text.translatable("message.cubecup.ball_spawned").formatted(Formatting.GREEN));
        return 1;
    }

    private static int recenterBall(CommandContext<ServerCommandSource> ctx) {
        Match match = requireMatch(ctx);
        if (match == null) return 0;
        match.kickoff(ctx.getSource().getServer(), false);
        feedback(ctx, Text.translatable("message.cubecup.ball_recentered").formatted(Formatting.GREEN));
        return 1;
    }

    private static int clearBalls(CommandContext<ServerCommandSource> ctx) {
        ServerWorld world = ctx.getSource().getWorld();
        Vec3d pos = ctx.getSource().getPosition();
        Box area = new Box(pos.add(-100, -60, -100), pos.add(100, 60, 100));
        int[] removed = {0};
        world.getEntitiesByClass(SoccerBallEntity.class, area, b -> true).forEach(ball -> {
            ball.discard();
            removed[0]++;
        });
        feedback(ctx, Text.translatable("message.cubecup.balls_cleared", removed[0]).formatted(Formatting.GRAY));
        return removed[0];
    }

    // ------------------------------------------------------------------

    private static Match requireMatch(CommandContext<ServerCommandSource> ctx) {
        Match match = MatchManager.get();
        if (match == null) {
            ctx.getSource().sendError(Text.translatable("message.cubecup.no_match"));
        }
        return match;
    }

    private static void feedback(CommandContext<ServerCommandSource> ctx, Text text) {
        ctx.getSource().sendFeedback(() -> text, false);
    }
}
