package br.cubecup.registry;

import br.cubecup.CubeCup;
import br.cubecup.block.*;
import br.cubecup.match.Team;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Todos os blocos do mod (estrutura de gol, campo e arquibancada). */
public final class ModBlocks {

    /** Ordem de exibicao na aba criativa. */
    public static final List<Block> CREATIVE_ORDER = new ArrayList<>();

    // Gol
    public static Block GOAL_DETECTOR_RED;
    public static Block GOAL_DETECTOR_BLUE;
    public static Block GOAL_POST;
    public static Block GOAL_NET;

    // Campo
    public static Block FIELD_LINE;
    public static Block PENALTY_SPOT;
    public static Block CORNER_FLAG_RED;
    public static Block CORNER_FLAG_BLUE;

    // Arquibancada / cenario
    public static Block SEAT_RED;
    public static Block SEAT_BLUE;
    public static Block AD_BOARD;

    private ModBlocks() {}

    private static Block register(String name, Block block) {
        Block registered = Registry.register(Registries.BLOCK, CubeCup.id(name), block);
        Registry.register(Registries.ITEM, CubeCup.id(name),
                new BlockItem(registered, new Item.Settings()));
        CREATIVE_ORDER.add(registered);
        return registered;
    }

    public static void register() {
        AbstractBlock.Settings stone = AbstractBlock.Settings.copy(Blocks.STONE).strength(1.5f);
        AbstractBlock.Settings wool = AbstractBlock.Settings.copy(Blocks.WHITE_WOOL);

        GOAL_DETECTOR_RED = register("goal_detector_red",
                new GoalDetectorBlock(Team.RED, AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(2.0f)));
        GOAL_DETECTOR_BLUE = register("goal_detector_blue",
                new GoalDetectorBlock(Team.BLUE, AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(2.0f)));

        GOAL_POST = register("goal_post",
                new Block(AbstractBlock.Settings.copy(Blocks.QUARTZ_BLOCK).strength(1.2f)
                        .sounds(BlockSoundGroup.METAL)));
        GOAL_NET = register("goal_net", new GoalNetBlock(
                AbstractBlock.Settings.copy(Blocks.GLASS).strength(0.6f).nonOpaque()));

        FIELD_LINE = register("field_line", new FlatDecorBlock(
                AbstractBlock.Settings.copy(Blocks.WHITE_CONCRETE).strength(0.6f), 1.0));
        PENALTY_SPOT = register("penalty_spot", new FlatDecorBlock(
                AbstractBlock.Settings.copy(Blocks.WHITE_CONCRETE).strength(0.6f), 1.0));

        CORNER_FLAG_RED = register("corner_flag_red", new CornerFlagBlock(
                AbstractBlock.Settings.copy(Blocks.OAK_FENCE).strength(0.4f).nonOpaque().noCollision()));
        CORNER_FLAG_BLUE = register("corner_flag_blue", new CornerFlagBlock(
                AbstractBlock.Settings.copy(Blocks.OAK_FENCE).strength(0.4f).nonOpaque().noCollision()));

        SEAT_RED = register("seat_red", new StadiumSeatBlock(wool.strength(0.8f)));
        SEAT_BLUE = register("seat_blue", new StadiumSeatBlock(AbstractBlock.Settings.copy(Blocks.BLUE_WOOL).strength(0.8f)));
        AD_BOARD = register("ad_board", new Block(stone));
    }

    /** Util para logs/debug. */
    public static Identifier idOf(Block block) {
        return Registries.BLOCK.getId(block);
    }
}
