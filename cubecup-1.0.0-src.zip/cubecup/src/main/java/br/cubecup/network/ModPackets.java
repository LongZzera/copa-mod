package br.cubecup.network;

import br.cubecup.CubeCup;
import br.cubecup.config.CubeCupConfig;
import br.cubecup.entity.SoccerBallEntity;
import br.cubecup.item.KickPower;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Rede do mod.
 *
 * Unico pacote: KICK (cliente -> servidor). O cliente so manda "qual tecla" foi
 * apertada; quem decide QUAL bola foi acertada e o servidor, refazendo o raycast.
 * Isso impede clientes modificados de chutar bolas do outro lado do mapa.
 */
public final class ModPackets {

    public static final Identifier KICK = CubeCup.id("kick");

    /** Ultimo tick em que cada jogador chutou (anti-spam do lado do servidor). */
    private static final Map<UUID, Long> LAST_KICK = new HashMap<>();

    private ModPackets() {}

    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(KICK, (server, player, handler, buf, responseSender) -> {
            int ordinal = buf.readByte();
            server.execute(() -> handleKick(player, KickPower.byOrdinal(ordinal)));
        });
    }

    private static void handleKick(ServerPlayerEntity player, KickPower power) {
        if (player.isSpectator() || !player.isAlive()) return;

        CubeCupConfig.Values cfg = CubeCupConfig.get();

        // Cooldown server-side: nao confia no cliente para limitar a cadencia.
        long now = player.getWorld().getTime();
        Long last = LAST_KICK.get(player.getUuid());
        if (last != null && now - last < cfg.kickCooldownTicks) return;
        LAST_KICK.put(player.getUuid(), now);
        SoccerBallEntity ball = findTargetBall(player, cfg.kickReach);
        if (ball == null) return;

        ball.kick(player, power);
    }

    /**
     * Acha a bola "mirada": dentro do alcance, na frente do jogador e com o melhor
     * compromisso entre proximidade e alinhamento com a mira.
     */
    public static SoccerBallEntity findTargetBall(ServerPlayerEntity player, double reach) {
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0f);
        Box search = player.getBoundingBox().stretch(look.multiply(reach)).expand(1.5);

        List<Entity> candidates = player.getWorld().getOtherEntities(player, search,
                e -> e instanceof SoccerBallEntity);

        SoccerBallEntity best = null;
        double bestScore = -1.0;

        for (Entity entity : candidates) {
            Vec3d toBall = entity.getPos().add(0.0, 0.35, 0.0).subtract(eye);
            double distance = toBall.length();
            if (distance > reach) continue;

            double alignment = toBall.normalize().dotProduct(look);
            if (alignment < 0.35) continue; // esta atras / muito de lado

            double score = alignment / Math.max(0.6, distance);
            if (score > bestScore) {
                bestScore = score;
                best = (SoccerBallEntity) entity;
            }
        }
        return best;
    }
}
