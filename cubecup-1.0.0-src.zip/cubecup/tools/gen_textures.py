#!/usr/bin/env python3
"""
Gera TODAS as texturas do mod proceduralmente (PIL + random deterministico).

Por que procedural em vez de PNGs soltos no repo:
  - o resultado e reproduzivel (seed fixa) e facil de ajustar (mude a paleta e rode de novo)
  - da pra versionar o "codigo da arte" no git em vez de binarios
  - serve como base decente para quem quiser repintar a mao depois

Uso:  python3 tools/gen_textures.py
"""
import os
import random

from PIL import Image, ImageDraw

random.seed(20260727)

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cubecup")
MC_ASSETS = os.path.join(ROOT, "src/main/resources/assets/minecraft")

# ------------------------------------------------------------------ paleta
SULFUR_LIGHT = (233, 226, 108)
SULFUR = (200, 193, 74)
SULFUR_DARK = (150, 143, 48)
SULFUR_DEEP = (104, 99, 32)

RED = (196, 44, 44)
RED_DARK = (140, 28, 28)
RED_LIGHT = (232, 88, 88)
BLUE = (48, 76, 208)
BLUE_DARK = (30, 50, 150)
BLUE_LIGHT = (98, 128, 240)
WHITE = (240, 240, 240)
WHITE_DARK = (198, 198, 198)
GRASS = (86, 140, 58)
GOLD = (232, 190, 66)
GOLD_DARK = (168, 128, 30)
GOLD_LIGHT = (255, 232, 140)
SILVER = (198, 200, 206)
SILVER_DARK = (140, 142, 150)
LEATHER = (128, 84, 44)
LEATHER_DARK = (88, 56, 28)
BLACK = (28, 28, 32)
GREY = (110, 112, 118)


def save(img, *parts):
    path = os.path.join(*parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


def noise(img, colors, weights, box=None, alpha=255):
    """Preenche uma regiao com ruido ponderado (visual mineral do enxofre)."""
    draw = ImageDraw.Draw(img)
    x0, y0, x1, y1 = box or (0, 0, img.width, img.height)
    for y in range(y0, y1):
        for x in range(x0, x1):
            draw.point((x, y), random.choices(colors, weights)[0] + (alpha,))


def sulfur_noise(img, box=None):
    noise(img, [SULFUR, SULFUR_LIGHT, SULFUR_DARK, SULFUR_DEEP], [55, 20, 20, 5], box)


# ------------------------------------------------------------- sprites ASCII
def from_ascii(grid, palette, size=16):
    """Constroi um sprite a partir de uma grade de caracteres. '.' = transparente."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    for y, row in enumerate(grid):
        for x, ch in enumerate(row):
            if ch == "." or ch not in palette:
                continue
            draw.point((x, y), palette[ch] + (255,))
    return img


JERSEY = [
    "................",
    "..XX........XX..",
    ".XSSX......XSSX.",
    "XSSSSXXXXXXSSSSX",
    "XSSSSSSSSSSSSSSX",
    "XSSSXSSLLSSXSSSX",
    "XSSSXSLLLLSXSSSX",
    ".XXXXSLLLLSXXXX.",
    "....XSSLLSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    ".....XXXXXX.....",
    "................",
]

SHORTS = [
    "................",
    "................",
    "................",
    "....XXXXXXXX....",
    "...XSSSSSSSSX...",
    "...XSSSSSSSSX...",
    "...XSLLLLLLSX...",
    "...XSSSSSSSSX...",
    "...XSSSXXSSSX...",
    "...XSSSX.XSSX...",
    "...XSSSX.XSSX...",
    "...XSSSX.XSSX...",
    "...XXXXX.XXXX...",
    "................",
    "................",
    "................",
]

SOCKS = [
    "................",
    "................",
    "..XXXX....XXXX..",
    "..XSSX....XSSX..",
    "..XLLX....XLLX..",
    "..XSSX....XSSX..",
    "..XSSX....XSSX..",
    "..XSSX....XSSX..",
    "..XSSX....XSSX..",
    "..XSSX....XSSX..",
    "..XSSX....XSSX..",
    "..XSSXX...XSSXX.",
    "..XSSSX...XSSSX.",
    "..XXXXX...XXXXX.",
    "................",
    "................",
]

CLEATS = [
    "................",
    "................",
    "................",
    "................",
    "...XXXX.........",
    "..XSSSSX........",
    "..XSLLSXXXXX....",
    "..XSSSSSSSSSX...",
    "..XSSSSSSSSSSX..",
    "..XWWWWWWWWWWX..",
    "..XXXXXXXXXXXX..",
    "...B..B..B..B...",
    "................",
    "................",
    "................",
    "................",
]

WHISTLE = [
    "................",
    "................",
    "................",
    "......SSSS......",
    ".....SLLLLS.....",
    "....SLLLLLLS....",
    "..SSSLLLLLLS....",
    ".SLLLLLLDLLS....",
    ".SLLLLLLLLLS....",
    "..SSSLLLLLLS....",
    "....SLLLLLLS....",
    ".....SLLLLS.....",
    "......SSSS......",
    "................",
    "................",
    "................",
]

CARD = [
    "................",
    "................",
    ".....XXXXXX.....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    "....XSSSSSSX....",
    ".....XXXXXX.....",
    "................",
    "................",
]

BAG = [
    "................",
    "................",
    "......LL........",
    ".....L..L.......",
    "....LLLLLL......",
    "...XXXXXXXXX....",
    "..XBBBBBBBBBX...",
    "..XBBYYYYBBBX...",
    "..XBYYYYYYBBX...",
    "..XBYYYYYYBBX...",
    "..XBBYYYYBBBX...",
    "..XBBBBBBBBBX...",
    "..XBBBBBBBBBX...",
    "...XXXXXXXXX....",
    "................",
    "................",
]

TROPHY = [
    "................",
    "...GGGGGGGGGG...",
    "...GHHHHHHHHG...",
    "..GGHHHHHHHHGG..",
    ".GD.GHHHHHHG.DG.",
    ".GD.GHHHHHHG.DG.",
    ".GD..GHHHHG..DG.",
    ".GD...GHHG...DG.",
    "..GG..GHHG..GG..",
    ".......GG.......",
    ".......GG.......",
    "......GGGG......",
    "....GGGGGGGG....",
    "...DDDDDDDDDD...",
    "...DDDDDDDDDD...",
    "................",
]

BALLON_DOR = [
    "................",
    ".....GGGGGG.....",
    "...GGHHHHHHGG...",
    "..GHHHHHHHHHHG..",
    "..GHHDDHHDDHHG..",
    ".GHHHHHHHHHHHHG.",
    ".GHHDDHHHHDDHHG.",
    ".GHHHHHHHHHHHHG.",
    "..GHHDDHHDDHHG..",
    "..GHHHHHHHHHHG..",
    "...GGHHHHHHGG...",
    ".....GGGGGG.....",
    "......GGGG......",
    "....GGGGGGGG....",
    "...DDDDDDDDDD...",
    "................",
]


def team_palette(team):
    if team == "red":
        return {"X": RED_DARK, "S": RED, "L": WHITE, "W": BLACK, "B": GREY}
    return {"X": BLUE_DARK, "S": BLUE, "L": WHITE, "W": BLACK, "B": GREY}


# ------------------------------------------------------------------ itens
def gen_items():
    out = os.path.join(ASSETS, "textures/item")

    # --- bola: cubo isometrico de enxofre ---
    ball = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(ball)
    top = [(8, 1), (14, 4), (8, 7), (2, 4)]
    left = [(2, 4), (8, 7), (8, 14), (2, 11)]
    right = [(14, 4), (8, 7), (8, 14), (14, 11)]
    d.polygon(top, fill=SULFUR_LIGHT + (255,))
    d.polygon(left, fill=SULFUR_DARK + (255,))
    d.polygon(right, fill=SULFUR + (255,))
    # granulado mineral
    for _ in range(70):
        x, y = random.randint(2, 14), random.randint(1, 14)
        if ball.getpixel((x, y))[3] == 0:
            continue
        base = ball.getpixel((x, y))[:3]
        shift = random.choice([-26, -14, 14, 22])
        d.point((x, y), tuple(max(0, min(255, c + shift)) for c in base) + (255,))
    # contorno
    for poly in (top, left, right):
        d.polygon(poly, outline=SULFUR_DEEP + (255,))
    save(ball, out, "soccer_ball.png")

    # --- resto dos itens via ASCII ---
    save(from_ascii(BAG, {"X": LEATHER_DARK, "B": LEATHER, "Y": SULFUR, "L": LEATHER_DARK}),
         out, "ball_bag.png")
    save(from_ascii(WHISTLE, {"S": SILVER_DARK, "L": SILVER, "D": BLACK}), out, "whistle.png")
    save(from_ascii(CARD, {"X": (140, 120, 20), "S": (247, 216, 44)}), out, "yellow_card.png")
    save(from_ascii(CARD, {"X": RED_DARK, "S": (222, 52, 52)}), out, "red_card.png")

    for team in ("red", "blue"):
        pal = team_palette(team)
        save(from_ascii(JERSEY, pal), out, f"{team}_jersey.png")
        save(from_ascii(SHORTS, pal), out, f"{team}_shorts.png")
        save(from_ascii(SOCKS, pal), out, f"{team}_socks.png")
        save(from_ascii(CLEATS, pal), out, f"{team}_cleats.png")

    save(from_ascii(TROPHY, {"G": GOLD, "H": GOLD_LIGHT, "D": GOLD_DARK}),
         out, "trophy_world_cup.png")
    save(from_ascii(TROPHY, {"G": SILVER, "H": (232, 234, 240), "D": SILVER_DARK}),
         out, "trophy_champions.png")
    save(from_ascii(TROPHY, {"G": (206, 158, 48), "H": (240, 210, 120), "D": (120, 88, 24)}),
         out, "trophy_libertadores.png")
    save(from_ascii(BALLON_DOR, {"G": GOLD_DARK, "H": GOLD, "D": GOLD_LIGHT}),
         out, "ballon_dor.png")


# ----------------------------------------------------------------- blocos
def flat_block(base, accent=None, accent_chance=0.10):
    img = Image.new("RGBA", (16, 16), base + (255,))
    if accent:
        d = ImageDraw.Draw(img)
        for y in range(16):
            for x in range(16):
                if random.random() < accent_chance:
                    d.point((x, y), accent + (255,))
    return img


def gen_blocks():
    out = os.path.join(ASSETS, "textures/block")

    # detectores: bloco escuro com o alvo do time no meio
    for team, color, dark in (("red", RED, RED_DARK), ("blue", BLUE, BLUE_DARK)):
        img = flat_block((44, 46, 52), (58, 60, 68), 0.25)
        d = ImageDraw.Draw(img)
        d.rectangle([3, 3, 12, 12], outline=color + (255,))
        d.rectangle([5, 5, 10, 10], fill=dark + (255,))
        d.rectangle([6, 6, 9, 9], fill=color + (255,))
        save(img, out, f"goal_detector_{team}.png")

    # trave: metal branco com sombreado vertical
    post = flat_block(WHITE, WHITE_DARK, 0.12)
    d = ImageDraw.Draw(post)
    d.line([(0, 0), (0, 15)], fill=WHITE_DARK + (255,))
    d.line([(15, 0), (15, 15)], fill=WHITE_DARK + (255,))
    save(post, out, "goal_post.png")

    # rede: malha transparente
    net = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(net)
    for i in range(0, 16, 3):
        d.line([(i, 0), (i, 15)], fill=(235, 235, 235, 210))
        d.line([(0, i), (15, i)], fill=(235, 235, 235, 210))
    save(net, out, "goal_net.png")

    # linha de campo: branco com um fio de grama nas bordas
    line = flat_block(WHITE, WHITE_DARK, 0.10)
    save(line, out, "field_line.png")

    spot = flat_block(GRASS, (76, 126, 50), 0.30)
    d = ImageDraw.Draw(spot)
    d.ellipse([5, 5, 10, 10], fill=WHITE + (255,))
    save(spot, out, "penalty_spot.png")

    # bandeirinhas (modelo cross)
    for team, color, dark in (("red", RED, RED_DARK), ("blue", BLUE, BLUE_DARK)):
        flag = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
        d = ImageDraw.Draw(flag)
        d.rectangle([7, 0, 8, 15], fill=(224, 224, 224, 255))   # mastro
        d.polygon([(9, 1), (15, 4), (9, 7)], fill=color + (255,))
        d.polygon([(9, 1), (15, 4), (9, 4)], fill=dark + (255,))
        save(flag, out, f"corner_flag_{team}.png")

    # assentos
    for team, color, dark in (("red", RED, RED_DARK), ("blue", BLUE, BLUE_DARK)):
        seat = flat_block(color, dark, 0.18)
        d = ImageDraw.Draw(seat)
        d.line([(0, 15), (15, 15)], fill=dark + (255,))
        save(seat, out, f"seat_{team}.png")

    # placa de publicidade
    ad = Image.new("RGBA", (16, 16), (18, 20, 26, 255))
    d = ImageDraw.Draw(ad)
    d.rectangle([0, 4, 15, 11], fill=WHITE + (255,))
    d.rectangle([1, 5, 4, 10], fill=SULFUR + (255,))
    d.rectangle([6, 6, 7, 9], fill=(20, 20, 20, 255))
    d.rectangle([9, 6, 10, 9], fill=(20, 20, 20, 255))
    d.rectangle([12, 6, 13, 9], fill=(20, 20, 20, 255))
    save(ad, out, "ad_board.png")


# ------------------------------------------------------- entidade + armadura
def gen_entity():
    """Textura da bola (64x32). O cubo usa 48x24; preencher tudo evita erro de UV."""
    img = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    sulfur_noise(img, (0, 0, 64, 32))
    d = ImageDraw.Draw(img)
    # cristais mais claros espalhados
    for _ in range(26):
        x, y = random.randint(0, 61), random.randint(0, 29)
        d.rectangle([x, y, x + random.randint(0, 2), y + random.randint(0, 2)],
                    fill=SULFUR_LIGHT + (255,))
    # veios escuros = "sujeira" mineral
    for _ in range(18):
        x, y = random.randint(0, 60), random.randint(0, 28)
        d.line([(x, y), (x + random.randint(-3, 3), y + random.randint(-2, 2))],
               fill=SULFUR_DEEP + (255,))
    # contornos das faces 12x12 (o cubo ocupa 4 colunas x 2 linhas de 12px)
    for cx in range(0, 49, 12):
        d.line([(cx, 0), (cx, 23)], fill=SULFUR_DEEP + (255,))
    for cy in range(0, 25, 12):
        d.line([(0, cy), (47, cy)], fill=SULFUR_DEEP + (255,))
    save(img, ASSETS, "textures/entity/soccer_ball.png")

    # textura vazia para o renderer do assento
    save(Image.new("RGBA", (4, 4), (0, 0, 0, 0)), ASSETS, "textures/entity/empty.png")


def armor_layer(base, stripe, size=(64, 32)):
    img = Image.new("RGBA", size, base + (255,))
    d = ImageDraw.Draw(img)
    for x in range(0, size[0], 6):
        d.line([(x, 0), (x, size[1])], fill=stripe + (255,))
    # sombreado leve nas bordas
    for y in range(size[1]):
        for x in range(size[0]):
            if (x + y) % 17 == 0:
                r, g, b, a = img.getpixel((x, y))
                d.point((x, y), (max(0, r - 18), max(0, g - 18), max(0, b - 18), a))
    return img


def gen_armor():
    """
    IMPORTANTE: em 1.20.1 o vanilla resolve a textura de armadura no namespace
    'minecraft', entao os arquivos ficam em assets/minecraft/textures/models/armor/.
    Os nomes sao unicos, sem risco de sobrescrever nada do jogo.
    """
    out = os.path.join(MC_ASSETS, "textures/models/armor")
    combos = {
        "soccer_red": (RED, WHITE),
        "soccer_blue": (BLUE, WHITE),
        "cleats_red": (RED_DARK, BLACK),
        "cleats_blue": (BLUE_DARK, BLACK),
    }
    for name, (base, stripe) in combos.items():
        save(armor_layer(base, stripe), out, f"{name}_layer_1.png")
        save(armor_layer(base, stripe), out, f"{name}_layer_2.png")


def gen_icon():
    """Icone do mod (128x128) mostrado na lista de mods."""
    img = Image.new("RGBA", (128, 128), (34, 90, 44, 255))
    d = ImageDraw.Draw(img)
    for _ in range(1400):
        x, y = random.randint(0, 127), random.randint(0, 127)
        d.point((x, y), (28 + random.randint(0, 26), 96 + random.randint(0, 30), 40, 255))
    d.rectangle([8, 8, 119, 119], outline=(240, 240, 240, 255), width=3)
    d.ellipse([44, 44, 84, 84], outline=(240, 240, 240, 255), width=3)
    top = [(64, 30), (98, 48), (64, 66), (30, 48)]
    left = [(30, 48), (64, 66), (64, 104), (30, 86)]
    right = [(98, 48), (64, 66), (64, 104), (98, 86)]
    d.polygon(top, fill=SULFUR_LIGHT + (255,))
    d.polygon(left, fill=SULFUR_DARK + (255,))
    d.polygon(right, fill=SULFUR + (255,))
    for _ in range(900):
        x, y = random.randint(30, 98), random.randint(30, 104)
        if img.getpixel((x, y))[:3] in (SULFUR_LIGHT, SULFUR, SULFUR_DARK):
            base = img.getpixel((x, y))[:3]
            shift = random.choice([-22, -12, 12, 20])
            d.point((x, y), tuple(max(0, min(255, c + shift)) for c in base) + (255,))
    save(img, ASSETS, "icon.png")


if __name__ == "__main__":
    gen_items()
    gen_blocks()
    gen_entity()
    gen_armor()
    gen_icon()
    print("Texturas geradas com sucesso.")
