package br.cubecup.registry;

import br.cubecup.CubeCup;
import br.cubecup.config.CubeCupConfig;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

/**
 * Sons do mod. Cada som custom tem um equivalente vanilla de fallback:
 * se o jogador desativar "customSounds" na config (ou nao instalar o resource pack
 * com os .ogg), o mod continua soando bem.
 */
public final class ModSounds {

    public static SoundEvent BALL_KICK;
    public static SoundEvent BALL_BOUNCE;
    public static SoundEvent GOAL;
    public static SoundEvent WHISTLE;
    public static SoundEvent CROWD;

    private ModSounds() {}

    private static SoundEvent register(String name) {
        Identifier id = CubeCup.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        BALL_KICK = register("ball_kick");
        BALL_BOUNCE = register("ball_bounce");
        GOAL = register("goal");
        WHISTLE = register("whistle");
        CROWD = register("crowd");
    }

    private static boolean custom() {
        return CubeCupConfig.get().customSounds;
    }

    public static SoundEvent kick()   { return custom() ? BALL_KICK   : SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP; }
    public static SoundEvent bounce() { return custom() ? BALL_BOUNCE : SoundEvents.BLOCK_SLIME_BLOCK_FALL; }
    public static SoundEvent goal()   { return custom() ? GOAL        : SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST; }
    public static SoundEvent whistle(){ return custom() ? WHISTLE     : SoundEvents.BLOCK_NOTE_BLOCK_FLUTE.value(); }
    public static SoundEvent crowd()  { return custom() ? CROWD       : SoundEvents.ENTITY_VILLAGER_CELEBRATE; }
}
