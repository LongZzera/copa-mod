package br.cubecup.client;

import br.cubecup.item.KickPower;
import br.cubecup.network.ModPackets;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.math.MathHelper;
import io.netty.buffer.Unpooled;
import org.lwjgl.glfw.GLFW;

/**
 * Teclas de chute. Todas remapeaveis em Opcoes > Controles > Cube Cup.
 * Padroes: G (fraco), H (medio), J (forte), R (powershot).
 */
public final class ModKeybinds {

    private static final String CATEGORY = "key.category.cubecup";

    public static KeyBinding KICK_WEAK;
    public static KeyBinding KICK_MEDIUM;
    public static KeyBinding KICK_STRONG;
    public static KeyBinding KICK_POWER;

    private ModKeybinds() {}

    public static void register() {
        KICK_WEAK = bind("key.cubecup.kick_weak", GLFW.GLFW_KEY_G);
        KICK_MEDIUM = bind("key.cubecup.kick_medium", GLFW.GLFW_KEY_H);
        KICK_STRONG = bind("key.cubecup.kick_strong", GLFW.GLFW_KEY_J);
        KICK_POWER = bind("key.cubecup.kick_power", GLFW.GLFW_KEY_R);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (KICK_WEAK.wasPressed())   sendKick(KickPower.WEAK);
            while (KICK_MEDIUM.wasPressed()) sendKick(KickPower.MEDIUM);
            while (KICK_STRONG.wasPressed()) sendKick(KickPower.STRONG);
            while (KICK_POWER.wasPressed())  sendKick(KickPower.POWER);
        });
    }

    private static KeyBinding bind(String translationKey, int key) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyBinding(translationKey, InputUtil.Type.KEYSYM, key, CATEGORY));
    }

    private static void sendKick(KickPower power) {
        PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
        buf.writeByte(MathHelper.clamp(power.ordinal(), 0, 3));
        ClientPlayNetworking.send(ModPackets.KICK, buf);
    }
}
