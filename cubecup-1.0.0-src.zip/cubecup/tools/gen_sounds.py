#!/usr/bin/env python3
"""
Sintetiza os sons do mod e exporta em OGG mono 44.1kHz (formato que o
Minecraft precisa para audio posicional).

Requisitos: numpy + ffmpeg no PATH.
Uso:  python3 tools/gen_sounds.py

Sao sons "placeholder de qualidade": funcionam bem no jogo, mas se voce tiver
samples reais (apito de arbitro, torcida gravada), basta substituir os .ogg em
src/main/resources/assets/cubecup/sounds/ mantendo os mesmos nomes.
"""
import os
import subprocess
import tempfile
import wave

import numpy as np

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "..", "src/main/resources/assets/cubecup/sounds")

rng = np.random.default_rng(20260727)


def t(seconds):
    return np.linspace(0, seconds, int(SR * seconds), endpoint=False)


def envelope(n, attack=0.01, release=0.2):
    env = np.ones(n)
    a = max(1, int(attack * SR))
    r = max(1, int(release * SR))
    env[:a] = np.linspace(0, 1, a)
    env[-r:] *= np.linspace(1, 0, r)
    return env


def lowpass(signal, alpha=0.15):
    out = np.zeros_like(signal)
    acc = 0.0
    for i, value in enumerate(signal):
        acc += alpha * (value - acc)
        out[i] = acc
    return out


def normalize(signal, peak=0.85):
    m = np.max(np.abs(signal)) or 1.0
    return signal / m * peak


def export(signal, name):
    signal = normalize(signal)
    pcm = (signal * 32767).astype(np.int16)

    os.makedirs(OUT, exist_ok=True)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wav_path = tmp.name
    with wave.open(wav_path, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(pcm.tobytes())

    ogg_path = os.path.join(OUT, f"{name}.ogg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav_path,
                    "-c:a", "libvorbis", "-q:a", "5", "-ac", "1", ogg_path], check=True)
    os.unlink(wav_path)
    print(f"  {name}.ogg")


# ------------------------------------------------------------------ sons
def whistle():
    """Apito de arbitro: duas frequencias proximas + trinado da bolinha."""
    x = t(0.55)
    trill = 1.0 + 0.35 * np.sin(2 * np.pi * 42 * x)          # a bolinha girando
    tone = (np.sin(2 * np.pi * 3150 * x * trill)
            + 0.75 * np.sin(2 * np.pi * 3660 * x * trill)
            + 0.30 * np.sin(2 * np.pi * 5100 * x))
    breath = 0.12 * lowpass(rng.normal(0, 1, len(x)), 0.5)
    return (tone + breath) * envelope(len(x), 0.015, 0.10)


def ball_kick():
    """Chute: estalo de couro (ruido) + corpo grave."""
    x = t(0.22)
    slap = rng.normal(0, 1, len(x)) * np.exp(-x * 90)
    slap = slap - lowpass(slap, 0.25)                         # deixa mais "seco"
    body = np.sin(2 * np.pi * 130 * x) * np.exp(-x * 32)
    thud = np.sin(2 * np.pi * 68 * x) * np.exp(-x * 20) * 0.6
    return (slap * 0.9 + body + thud) * envelope(len(x), 0.002, 0.06)


def ball_bounce():
    """Quique: mais curto e mais agudo que o chute."""
    x = t(0.16)
    click = rng.normal(0, 1, len(x)) * np.exp(-x * 150)
    ring = np.sin(2 * np.pi * 220 * x) * np.exp(-x * 45)
    return (click * 0.7 + ring) * envelope(len(x), 0.001, 0.05)


def goal():
    """Fanfarra curta: acorde maior ascendente + brilho."""
    notes = [392.0, 523.25, 659.25, 783.99]                   # Sol - Do - Mi - Sol
    total = np.zeros(int(SR * 1.6))
    for i, freq in enumerate(notes):
        start = int(SR * 0.16 * i)
        x = t(1.6 - 0.16 * i)
        voice = (np.sin(2 * np.pi * freq * x)
                 + 0.45 * np.sin(2 * np.pi * freq * 2 * x)
                 + 0.20 * np.sin(2 * np.pi * freq * 3 * x))
        voice *= np.exp(-x * 2.2) * envelope(len(x), 0.01, 0.4)
        total[start:start + len(voice)] += voice * 0.6
    sparkle = rng.normal(0, 1, len(total)) * np.exp(-t(1.6) * 6) * 0.08
    return total + sparkle


def crowd():
    """Torcida: ruido rosa filtrado com um 'olé' em forma de envelope."""
    x = t(3.2)
    base = lowpass(rng.normal(0, 1, len(x)), 0.06)
    base += 0.35 * lowpass(rng.normal(0, 1, len(x)), 0.02)
    swell = 0.35 + 0.65 * np.clip(np.sin(np.pi * x / 3.2), 0, 1) ** 0.7
    voices = sum(0.05 * np.sin(2 * np.pi * f * x + rng.uniform(0, 6)) for f in (180, 240, 300, 360))
    return (base * swell + voices * swell) * envelope(len(x), 0.25, 0.9)


if __name__ == "__main__":
    print("Gerando sons...")
    export(whistle(), "whistle")
    export(ball_kick(), "ball_kick")
    export(ball_bounce(), "ball_bounce")
    export(goal(), "goal")
    export(crowd(), "crowd")
    print("Sons gerados com sucesso.")
