package br.cubecup.registry;

import br.cubecup.CubeCup;
import br.cubecup.entity.SeatEntity;
import br.cubecup.entity.SoccerBallEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/** Entidades customizadas: a bola e o "assento" invisivel das arquibancadas. */
public final class ModEntities {

    public static EntityType<SoccerBallEntity> SOCCER_BALL;
    public static EntityType<SeatEntity> SEAT;

    private ModEntities() {}

    public static void register() {
        SOCCER_BALL = Registry.register(Registries.ENTITY_TYPE, CubeCup.id("soccer_ball"),
                FabricEntityTypeBuilder.<SoccerBallEntity>create(SpawnGroup.MISC, SoccerBallEntity::new)
                        .dimensions(EntityDimensions.fixed(0.72f, 0.72f))
                        // trackRange alto + update rate 1 => bola suave mesmo voando rapido no multiplayer
                        .trackRangeBlocks(128)
                        .trackedUpdateRate(1)
                        .forceTrackedVelocityUpdates(true)
                        .build());

        SEAT = Registry.register(Registries.ENTITY_TYPE, CubeCup.id("seat"),
                FabricEntityTypeBuilder.<SeatEntity>create(SpawnGroup.MISC, SeatEntity::new)
                        .dimensions(EntityDimensions.fixed(0.01f, 0.01f))
                        .trackRangeBlocks(16)
                        .disableSaving()
                        .build());
    }
}
