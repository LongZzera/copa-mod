#!/usr/bin/env python3
"""
Gera todos os arquivos JSON repetitivos do resource/data pack:
blockstates, modelos de bloco e item, loot tables, sounds.json e os idiomas.

Uso:  python3 tools/gen_assets.py
(rode a partir da raiz do projeto)
"""
import json
import os

MODID = "cubecup"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
ASSETS = os.path.join(ROOT, "src/main/resources/assets", MODID)
DATA = os.path.join(ROOT, "src/main/resources/data", MODID)


def write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


# ---------------------------------------------------------------- blocos
# nome -> tipo de modelo
BLOCKS = {
    "goal_detector_red": "cube",
    "goal_detector_blue": "cube",
    "goal_post": "cube",
    "goal_net": "cube",
    "ad_board": "cube",
    "field_line": "flat",
    "penalty_spot": "flat",
    "corner_flag_red": "cross",
    "corner_flag_blue": "cross",
    "seat_red": "seat",
    "seat_blue": "seat",
}

# blocos com a propriedade "large" (detector de gol)
LARGE_PROP = {"goal_detector_red", "goal_detector_blue"}

ITEMS = [
    "soccer_ball", "ball_bag", "whistle", "yellow_card", "red_card",
    "red_jersey", "red_shorts", "red_socks", "red_cleats",
    "blue_jersey", "blue_shorts", "blue_socks", "blue_cleats",
    "trophy_world_cup", "trophy_champions", "trophy_libertadores", "ballon_dor",
]


def block_model(name, kind):
    tex = f"{MODID}:block/{name}"
    if kind == "cube":
        return {"parent": "minecraft:block/cube_all", "textures": {"all": tex}}
    if kind == "cross":
        return {"parent": "minecraft:block/cross", "textures": {"cross": tex}}
    if kind == "flat":
        return {
            "parent": "minecraft:block/block",
            "textures": {"all": tex, "particle": tex},
            "elements": [{
                "from": [0, 0, 0], "to": [16, 1, 16],
                "faces": {
                    "down": {"uv": [0, 0, 16, 16], "texture": "#all", "cullface": "down"},
                    "up": {"uv": [0, 0, 16, 16], "texture": "#all"},
                    "north": {"uv": [0, 0, 16, 1], "texture": "#all"},
                    "south": {"uv": [0, 0, 16, 1], "texture": "#all"},
                    "west": {"uv": [0, 0, 16, 1], "texture": "#all"},
                    "east": {"uv": [0, 0, 16, 1], "texture": "#all"},
                },
            }],
        }
    if kind == "seat":
        return {
            "parent": "minecraft:block/block",
            "textures": {"all": tex, "particle": tex},
            "elements": [
                {"from": [1, 0, 1], "to": [15, 6, 15],
                 "faces": {f: {"uv": [0, 0, 16, 16], "texture": "#all"} for f in
                           ["down", "up", "north", "south", "west", "east"]}},
                {"from": [1, 6, 12], "to": [15, 14, 15],
                 "faces": {f: {"uv": [0, 0, 16, 16], "texture": "#all"} for f in
                           ["down", "up", "north", "south", "west", "east"]}},
            ],
        }
    raise ValueError(kind)


def main():
    # --- blockstates + modelos + item dos blocos + loot tables ---
    for name, kind in BLOCKS.items():
        model_id = f"{MODID}:block/{name}"

        if name in LARGE_PROP:
            variants = {"large=false": {"model": model_id}, "large=true": {"model": model_id}}
        else:
            variants = {"": {"model": model_id}}
        write(os.path.join(ASSETS, "blockstates", f"{name}.json"), {"variants": variants})

        write(os.path.join(ASSETS, "models/block", f"{name}.json"), block_model(name, kind))

        if kind == "cross":
            item_model = {"parent": "minecraft:item/generated",
                          "textures": {"layer0": f"{MODID}:block/{name}"}}
        else:
            item_model = {"parent": model_id}
        write(os.path.join(ASSETS, "models/item", f"{name}.json"), item_model)

        write(os.path.join(DATA, "loot_tables/blocks", f"{name}.json"), {
            "type": "minecraft:block",
            "pools": [{
                "rolls": 1,
                "bonus_rolls": 0,
                "entries": [{"type": "minecraft:item", "name": f"{MODID}:{name}"}],
                "conditions": [{"condition": "minecraft:survives_explosion"}],
            }],
        })

    # --- modelos dos itens ---
    for name in ITEMS:
        write(os.path.join(ASSETS, "models/item", f"{name}.json"), {
            "parent": "minecraft:item/generated",
            "textures": {"layer0": f"{MODID}:item/{name}"},
        })

    # --- sounds.json ---
    write(os.path.join(ASSETS, "sounds.json"), {
        "ball_kick": {"subtitle": "subtitles.cubecup.ball_kick",
                      "sounds": [{"name": f"{MODID}:ball_kick", "volume": 1.0}]},
        "ball_bounce": {"subtitle": "subtitles.cubecup.ball_bounce",
                        "sounds": [{"name": f"{MODID}:ball_bounce", "volume": 0.9}]},
        "goal": {"subtitle": "subtitles.cubecup.goal",
                 "sounds": [{"name": f"{MODID}:goal", "volume": 1.0}]},
        "whistle": {"subtitle": "subtitles.cubecup.whistle",
                    "sounds": [{"name": f"{MODID}:whistle", "volume": 1.0}]},
        "crowd": {"subtitle": "subtitles.cubecup.crowd",
                  "sounds": [{"name": f"{MODID}:crowd", "volume": 0.9}]},
    })

    # --- tags: tudo quebravel com picareta/enxada faz sentido para o campo ---
    write(os.path.join(ROOT, "src/main/resources/data/minecraft/tags/blocks/mineable/pickaxe.json"), {
        "replace": False,
        "values": [f"{MODID}:{n}" for n in
                   ["goal_detector_red", "goal_detector_blue", "goal_post", "goal_net", "ad_board"]],
    })

    print("Assets JSON gerados com sucesso.")


if __name__ == "__main__":
    main()
