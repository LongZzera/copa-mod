package br.cubecup.config;

import br.cubecup.CubeCup;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Config em JSON simples (sem dependencias externas tipo Cloth Config).
 * Arquivo gerado em: .minecraft/config/cubecup.json
 *
 * Todos os valores sao lidos em tempo de execucao, entao /futebol config recarregar
 * aplica mudancas sem reiniciar o jogo.
 */
public final class CubeCupConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Values values = new Values();

    private CubeCupConfig() {}

    public static Values get() {
        return values;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("cubecup.json");
    }

    public static void load() {
        Path file = path();
        try {
            if (Files.exists(file)) {
                Values loaded = GSON.fromJson(Files.readString(file), Values.class);
                if (loaded != null) values = loaded;
                CubeCup.LOGGER.info("[Cube Cup] Config carregada de {}", file);
            }
            save(); // reescreve para adicionar campos novos de versoes futuras
        } catch (Exception e) {
            CubeCup.LOGGER.error("[Cube Cup] Falha ao ler a config, usando padroes.", e);
            values = new Values();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(path().getParent());
            Files.writeString(path(), GSON.toJson(values));
        } catch (IOException e) {
            CubeCup.LOGGER.error("[Cube Cup] Falha ao salvar a config.", e);
        }
    }

    /** Todos os numeros ajustaveis do mod. */
    public static class Values {

        // ---------- Fisica da bola ----------
        /** Gravidade aplicada por tick (vanilla item = 0.04). Maior = bola mais pesada. */
        public double gravity = 0.045;
        /** Quanto da velocidade e mantida ao quicar (0 = morre no chao, 1 = quica pra sempre). */
        public double bounciness = 0.68;
        /** Atrito horizontal quando a bola esta no chao. */
        public double groundFriction = 0.90;
        /** Atrito horizontal no ar (resistencia do vento). */
        public double airFriction = 0.995;
        /** Fator aplicado quando a bola bate em parede lateral. */
        public double wallBounciness = 0.72;
        /** Velocidade maxima em blocos/tick (evita a bola sumir no infinito). */
        public double maxSpeed = 4.0;
        /** Abaixo desta velocidade vertical a bola para de quicar. */
        public double bounceThreshold = 0.09;
        /** Multiplicador do empurrao quando um jogador encosta na bola (drible). */
        public double dribbleStrength = 1.0;
        /** Arrasto dentro da agua. */
        public double waterDrag = 0.80;

        // ---------- Chutes ----------
        public double kickWeak = 0.55;
        public double kickMedium = 1.05;
        public double kickStrong = 1.75;
        public double kickPowerShot = 2.90;
        /** Elevacao extra somada a direcao do olhar (0 = rasteiro, 0.5 = balao). */
        public double kickLift = 0.22;
        /** Alcance (em blocos) para acertar a bola com as teclas de chute. */
        public double kickReach = 4.0;
        /** Cooldown entre chutes, em ticks. */
        public int kickCooldownTicks = 5;
        /** Bonus multiplicativo de forca das chuteiras especiais. */
        public double cleatsKickBonus = 1.35;
        /** Reducao do desvio aleatorio com chuteiras (0..1, 1 = chute perfeito). */
        public double cleatsAccuracy = 0.70;
        /** Desvio aleatorio base do chute em graus (o "caos" do Cube Cup). */
        public double kickSpread = 3.5;

        // ---------- Partida ----------
        public int defaultMatchMinutes = 10;
        public int defaultScoreLimit = 5;
        /** Contagem regressiva (ticks) apos um gol antes da bola voltar a valer. */
        public int kickoffDelayTicks = 60;
        /** Equipa automaticamente o uniforme ao entrar num time. */
        public boolean autoEquipUniform = true;
        /** Teleporta o jogador para o spawn do time no inicio e apos gols. */
        public boolean teleportOnKickoff = true;

        // ---------- Efeitos ----------
        public boolean particles = true;
        public boolean bounceSound = true;
        /** Se true usa os .ogg proprios do mod; se false usa sons vanilla equivalentes. */
        public boolean customSounds = true;
        /** Toca som de torcida quando sai gol. */
        public boolean crowdOnGoal = true;
        /** A bola some sozinha depois de N ticks parada e sem partida (0 = nunca). */
        public int idleDespawnTicks = 0;
    }
}
