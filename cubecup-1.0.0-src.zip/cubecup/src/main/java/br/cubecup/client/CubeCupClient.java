package br.cubecup.client;

import br.cubecup.client.render.SeatEntityRenderer;
import br.cubecup.client.render.SoccerBallModel;
import br.cubecup.client.render.SoccerBallRenderer;
import br.cubecup.registry.ModBlocks;
import br.cubecup.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;

/** Entrypoint do cliente: renderers, camadas de modelo e teclas. */
public class CubeCupClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.SOCCER_BALL,
                SoccerBallModel::getTexturedModelData);

        EntityRendererRegistry.register(ModEntities.SOCCER_BALL, SoccerBallRenderer::new);
        EntityRendererRegistry.register(ModEntities.SEAT, SeatEntityRenderer::new);

        // Blocos com transparencia
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(),
                ModBlocks.GOAL_NET,
                ModBlocks.CORNER_FLAG_RED,
                ModBlocks.CORNER_FLAG_BLUE,
                ModBlocks.FIELD_LINE,
                ModBlocks.PENALTY_SPOT);

        ModKeybinds.register();
    }
}
