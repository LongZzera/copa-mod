package br.cubecup.client.render;

import br.cubecup.CubeCup;
import br.cubecup.entity.SeatEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** O assento e invisivel: renderer vazio. */
public class SeatEntityRenderer extends EntityRenderer<SeatEntity> {

    public SeatEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public void render(SeatEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        // nada
    }

    @Override
    public Identifier getTexture(SeatEntity entity) {
        return CubeCup.id("textures/entity/empty.png");
    }
}
