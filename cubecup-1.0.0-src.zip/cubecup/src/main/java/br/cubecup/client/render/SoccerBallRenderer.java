package br.cubecup.client.render;

import br.cubecup.CubeCup;
import br.cubecup.client.ModModelLayers;
import br.cubecup.entity.SoccerBallEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Renderiza a bola girando na direcao do movimento.
 *
 * Truque: rotaciona o mundo para alinhar o eixo de rotacao com o vetor de
 * velocidade, aplica o "roll" acumulado e desfaz o alinhamento.
 */
public class SoccerBallRenderer extends EntityRenderer<SoccerBallEntity> {

    private static final Identifier TEXTURE = CubeCup.id("textures/entity/soccer_ball.png");

    private final SoccerBallModel model;

    public SoccerBallRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.shadowRadius = 0.35f;
        this.shadowOpacity = 0.7f;
        this.model = new SoccerBallModel(context.getPart(ModModelLayers.SOCCER_BALL));
    }

    @Override
    public void render(SoccerBallEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();
        matrices.translate(0.0, 0.36, 0.0); // centraliza o cubo na hitbox

        float roll = MathHelper.lerp(tickDelta, entity.prevRoll, entity.roll);
        float spin = MathHelper.lerp(tickDelta, entity.prevSpinYaw, entity.spinYaw);

        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-spin));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-roll));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(spin));

        matrices.scale(-1.0f, -1.0f, 1.0f); // convencao de modelos de entidade

        VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        model.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV, 1.0f, 1.0f, 1.0f, 1.0f);

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    @Override
    public Identifier getTexture(SoccerBallEntity entity) {
        return TEXTURE;
    }
}
